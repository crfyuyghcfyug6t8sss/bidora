<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';
require_once '../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // جلب معلومات المستخدم
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        throw new Exception('المستخدم غير موجود');
    }
    
    if ($user['email_verified']) {
        echo json_encode([
            'success' => false,
            'message' => 'البريد محقق بالفعل'
        ]);
        exit;
    }
    
    // حذف التوكنات القديمة
    $conn->prepare("DELETE FROM email_verifications WHERE user_id = ?")->execute([$user_id]);
    
    // توليد توكن جديد
    $verification_token = bin2hex(random_bytes(32));
    $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));
    
    $stmt = $conn->prepare("
        INSERT INTO email_verifications (user_id, token, expires_at) 
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$user_id, $verification_token, $expires_at]);
    
    // إرسال البريد
    $verification_link = 'https://bidora.de/auth/verify-email.php?token=' . $verification_token;
    
    $emailBody = "
    <!DOCTYPE html>
    <html dir='rtl' lang='ar'>
    <head><meta charset='UTF-8'></head>
    <body style='font-family: Cairo, Arial, sans-serif; direction: rtl; padding: 20px;'>
        <div style='background: white; padding: 40px; border-radius: 12px; max-width: 600px; margin: 0 auto;'>
            <h1 style='color: #6366f1; text-align: center;'>إعادة إرسال رابط التحقق</h1>
            <p>مرحباً <strong>" . htmlspecialchars($user['username']) . "</strong>،</p>
            <p>تم إرسال رابط تحقق جديد. اضغط على الزر للتحقق:</p>
            <div style='text-align: center; margin: 30px 0;'>
                <a href='" . $verification_link . "' style='display: inline-block; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; font-weight: 600;'>
                    تحقق من البريد الإلكتروني
                </a>
            </div>
            <p>صلاحية الرابط: 24 ساعة</p>
        </div>
    </body>
    </html>
    ";
    
    require_once '../includes/send-email.php';
    $email_sent = sendEmailViaSMTP($user['email'], 'إعادة إرسال رابط التحقق', $emailBody);
    
    if ($email_sent) {
        echo json_encode([
            'success' => true,
            'message' => 'تم إرسال رابط التحقق بنجاح! تحقق من بريدك'
        ]);
    } else {
        throw new Exception('فشل في إرسال البريد');
    }
    
} catch (Exception $e) {
    error_log("Resend verification error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>