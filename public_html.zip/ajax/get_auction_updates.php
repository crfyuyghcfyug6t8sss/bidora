<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid auction ID']);
    exit;
}

$auction_id = clean($_GET['id']);

try {
    // جلب تفاصيل المزاد المحدثة
    $stmt = $conn->prepare("
        SELECT 
            current_price,
            total_bids,
            highest_bidder_id,
            end_time
        FROM auctions
        WHERE id = ?
    ");
    $stmt->execute([$auction_id]);
    $auction = $stmt->fetch();

    if (!$auction) {
        echo json_encode(['success' => false, 'message' => 'Auction not found']);
        exit;
    }

    // جلب آخر 5 مزايدات
    $stmt = $conn->prepare("
        SELECT b.bid_amount, u.username, b.created_at
        FROM bids b
        JOIN users u ON b.user_id = u.id
        WHERE b.auction_id = ?
        ORDER BY b.bid_amount DESC, b.created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$auction_id]);
    $latest_bids = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // حساب الوقت المتبقي
    $now = time();
    $end = strtotime($auction['end_time']);
    $time_remaining = $end - $now;

    echo json_encode([
        'success' => true,
        'current_price' => (float)$auction['current_price'],
        'total_bids' => (int)$auction['total_bids'],
        'time_remaining' => $time_remaining,
        'latest_bids' => $latest_bids
    ]);

} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error'
    ]);
}
?>