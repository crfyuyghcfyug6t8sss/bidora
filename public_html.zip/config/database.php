<?php
// معلومات الاتصال بقاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'u916622264_car');  // غيّر حسب اسم قاعدتك
define('DB_USER', 'u916622264_car');        // غيّر حسب اليوزر تبعك
define('DB_PASS', 'Yazenstars1@');        // ضع الباسوورد اللي حطيته


// الاتصال بقاعدة البيانات
try {
    $conn = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch(PDOException $e) {
    die("فشل الاتصال بقاعدة البيانات: " . $e->getMessage());
}

// جعل $conn متغير عام
$GLOBALS['conn'] = $conn;
date_default_timezone_set('Asia/Amman')
?>