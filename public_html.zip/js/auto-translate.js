// ترجمة تلقائية لكل الصفحة
function translatePage() {
    const lang = getCookie('site_lang');
    
    if (!lang || lang === 'ar') {
        return; // لا حاجة للترجمة
    }
    
    // إظهار loader
    showLoader();
    
    // جمع كل النصوص العربية
    const arabicPattern = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+/g;
    const elements = document.querySelectorAll('*:not(script):not(style)');
    
    let textsToTranslate = [];
    let elementsMap = [];
    
    elements.forEach(element => {
        // التحقق من النصوص المباشرة فقط (ليس الأطفال)
        for (let node of element.childNodes) {
            if (node.nodeType === Node.TEXT_NODE) {
                const text = node.textContent.trim();
                if (arabicPattern.test(text) && text.length > 1) {
                    textsToTranslate.push(text);
                    elementsMap.push({
                        node: node,
                        original: text
                    });
                }
            }
        }
        
        // ترجمة الـ placeholders
        if (element.placeholder && arabicPattern.test(element.placeholder)) {
            textsToTranslate.push(element.placeholder);
            elementsMap.push({
                element: element,
                type: 'placeholder',
                original: element.placeholder
            });
        }
        
        // ترجمة الـ title
        if (element.title && arabicPattern.test(element.title)) {
            textsToTranslate.push(element.title);
            elementsMap.push({
                element: element,
                type: 'title',
                original: element.title
            });
        }
    });
    
    if (textsToTranslate.length === 0) {
        hideLoader();
        return;
    }
    
    // إرسال للترجمة
    fetch('translate-ajax.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            texts: textsToTranslate,
            target_lang: lang
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // تطبيق الترجمات
            elementsMap.forEach((item, index) => {
                const translated = data.translations[item.original];
                
                if (translated) {
                    if (item.node) {
                        item.node.textContent = translated;
                    } else if (item.type === 'placeholder') {
                        item.element.placeholder = translated;
                    } else if (item.type === 'title') {
                        item.element.title = translated;
                    }
                }
            });
        }
        hideLoader();
    })
    .catch(error => {
        console.error('Translation error:', error);
        hideLoader();
    });
}

// الحصول على Cookie
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}

// عرض Loader
function showLoader() {
    let loader = document.getElementById('translation-loader');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'translation-loader';
        loader.innerHTML = `
            <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); 
                        background: rgba(255,255,255,0.95); padding: 30px; border-radius: 15px; 
                        box-shadow: 0 10px 40px rgba(0,0,0,0.2); z-index: 99999; text-align: center;">
                <div style="width: 50px; height: 50px; border: 5px solid #f3f3f3; 
                            border-top: 5px solid #667eea; border-radius: 50%; 
                            animation: spin 1s linear infinite; margin: 0 auto 15px;"></div>
                <p style="color: #1e293b; font-weight: 600; margin: 0;">جاري الترجمة...</p>
            </div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;
        document.body.appendChild(loader);
    }
    loader.style.display = 'block';
}

// إخفاء Loader
function hideLoader() {
    const loader = document.getElementById('translation-loader');
    if (loader) {
        loader.style.display = 'none';
    }
}

// تشغيل الترجمة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', translatePage);