<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    setMessage('غير مصرح لك بالوصول', 'danger');
    redirect('../index.php');
}

$errors = [];
$success = '';

// ==================== معالجة العمليات ====================
// معالجة طلبات KYC
if (isset($_GET['approve_kyc'])) {
    $kyc_id = clean($_GET['approve_kyc']);
    
    try {
        $conn->beginTransaction();
        
        // الحصول على user_id
        $stmt = $conn->prepare("SELECT user_id FROM kyc_verifications WHERE id = ?");
        $stmt->execute([$kyc_id]);
        $kyc = $stmt->fetch();
        
        // تحديث حالة الطلب
        $stmt = $conn->prepare("UPDATE kyc_verifications SET status = 'approved', reviewed_at = NOW(), reviewed_by = ? WHERE id = ?");
        $stmt->execute([$_SESSION['user_id'], $kyc_id]);
        
        // تحديث حالة المستخدم
        $stmt = $conn->prepare("UPDATE users SET kyc_status = 'verified' WHERE id = ?");
        $stmt->execute([$kyc['user_id']]);
        
        // إرسال إشعار
        sendNotification($kyc['user_id'], 'تم الموافقة على طلب التحقق', 'تم التحقق من هويتك بنجاح! يمكنك الآن البيع والشراء', 'system', null);
        
        $conn->commit();
        $success = 'تمت الموافقة على الطلب';
    } catch(Exception $e) {
        $conn->rollBack();
        $errors[] = 'خطأ: ' . $e->getMessage();
    }
    
    header("Location: dashboard.php?view=kyc");
    exit;
}

if (isset($_GET['reject_kyc'])) {
    $kyc_id = clean($_GET['reject_kyc']);
    $reason = isset($_GET['reason']) ? clean($_GET['reason']) : 'لم يتم توضيح السبب';
    
    try {
        $conn->beginTransaction();
        
        // الحصول على user_id
        $stmt = $conn->prepare("SELECT user_id FROM kyc_verifications WHERE id = ?");
        $stmt->execute([$kyc_id]);
        $kyc = $stmt->fetch();
        
        // تحديث حالة الطلب
        $stmt = $conn->prepare("UPDATE kyc_verifications SET status = 'rejected', rejection_reason = ?, reviewed_at = NOW(), reviewed_by = ? WHERE id = ?");
        $stmt->execute([$reason, $_SESSION['user_id'], $kyc_id]);
        
        // تحديث حالة المستخدم
        $stmt = $conn->prepare("UPDATE users SET kyc_status = 'rejected' WHERE id = ?");
        $stmt->execute([$kyc['user_id']]);
        
        // إرسال إشعار
        sendNotification($kyc['user_id'], 'تم رفض طلب التحقق', 'السبب: ' . $reason, 'system', null);
        
        $conn->commit();
        $success = 'تم رفض الطلب';
    } catch(Exception $e) {
        $conn->rollBack();
        $errors[] = 'خطأ: ' . $e->getMessage();
    }
    
    header("Location: dashboard.php?view=kyc");
    exit;
}
// حذف/تعطيل مستخدم
if (isset($_GET['suspend_user'])) {
    $user_id = clean($_GET['suspend_user']);
    $stmt = $conn->prepare("UPDATE users SET status = 'suspended' WHERE id = ?");
    $stmt->execute([$user_id]);
    $success = 'تم تعطيل المستخدم';
    header("Location: dashboard.php?view=users");
    exit;
}

if (isset($_GET['activate_user'])) {
    $user_id = clean($_GET['activate_user']);
    $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
    $stmt->execute([$user_id]);
    $success = 'تم تفعيل المستخدم';
    header("Location: dashboard.php?view=users");
    exit;
}

// إلغاء مزاد
if (isset($_GET['cancel_auction'])) {
    $auction_id = clean($_GET['cancel_auction']);
    $stmt = $conn->prepare("UPDATE auctions SET status = 'cancelled' WHERE id = ?");
    $stmt->execute([$auction_id]);
    $success = 'تم إلغاء المزاد';
    header("Location: dashboard.php?view=auctions");
    exit;
}
// تعديل مزاد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_auction'])) {
    $auction_id = clean($_POST['auction_id']);
    $starting_price = clean($_POST['starting_price']);
    $min_bid_increment = clean($_POST['min_bid_increment']);
    $end_time = clean($_POST['end_time']);
    
    try {
        $stmt = $conn->prepare("
            UPDATE auctions 
            SET starting_price = ?, 
                min_bid_increment = ?,
                end_time = ?
            WHERE id = ?
        ");
        $stmt->execute([$starting_price, $min_bid_increment, $end_time, $auction_id]);
        $success = 'تم تحديث المزاد بنجاح';
    } catch(Exception $e) {
        $errors[] = 'خطأ: ' . $e->getMessage();
    }
}

// إنهاء مزاد فوراً
if (isset($_GET['force_end_auction'])) {
    $auction_id = clean($_GET['force_end_auction']);
    
    try {
        $conn->beginTransaction();
        
        // جلب بيانات المزاد
        $stmt = $conn->prepare("SELECT * FROM auctions WHERE id = ?");
        $stmt->execute([$auction_id]);
        $auction = $stmt->fetch();
        
        if ($auction && $auction['status'] == 'active') {
            // تحديث وقت الانتهاء للآن
            $stmt = $conn->prepare("UPDATE auctions SET end_time = NOW() WHERE id = ?");
            $stmt->execute([$auction_id]);
            
            $success = 'تم إنهاء المزاد فوراً. سيتم معالجته في الكرون التالي.';
        }
        
        $conn->commit();
    } catch(Exception $e) {
        $conn->rollBack();
        $errors[] = 'خطأ: ' . $e->getMessage();
    }
    
    header("Location: dashboard.php?view=auctions");
    exit;
}

// إكمال مزاد يدوياً
if (isset($_GET['manual_complete'])) {
    $auction_id = clean($_GET['manual_complete']);
    
    try {
        $stmt = $conn->prepare("UPDATE auctions SET status = 'completed' WHERE id = ?");
        $stmt->execute([$auction_id]);
        $success = 'تم تحديث حالة المزاد إلى مكتمل';
    } catch(Exception $e) {
        $errors[] = 'خطأ: ' . $e->getMessage();
    }
    
    header("Location: dashboard.php?view=auctions");
    exit;
}

// إعادة تفعيل مزاد منتهي
if (isset($_GET['reactivate_auction']) && isset($_GET['hours'])) {
    $auction_id = clean($_GET['reactivate_auction']);
    $hours = clean($_GET['hours']);
    
    try {
        $new_end_time = date('Y-m-d H:i:s', strtotime("+$hours hours"));
        $stmt = $conn->prepare("
            UPDATE auctions 
            SET status = 'active', 
                end_time = ? 
            WHERE id = ?
        ");
        $stmt->execute([$new_end_time, $auction_id]);
        $success = "تم إعادة تفعيل المزاد لمدة $hours ساعة";
    } catch(Exception $e) {
        $errors[] = 'خطأ: ' . $e->getMessage();
    }
    
    header("Location: dashboard.php?view=auctions");
    exit;
}

// إضافة شريحة عمولة
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_tier'])) {
    $min_price = clean($_POST['min_price']);
    $max_price = clean($_POST['max_price']);
    $commission_rate = clean($_POST['commission_rate']);
    
    if ($min_price >= $max_price) {
        $errors[] = 'السعر الأدنى يجب أن يكون أقل من السعر الأعلى';
    }
    
    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("INSERT INTO commission_tiers (min_price, max_price, commission_rate) VALUES (?, ?, ?)");
            $stmt->execute([$min_price, $max_price, $commission_rate]);
            $success = 'تم إضافة الشريحة بنجاح';
        } catch(PDOException $e) {
            $errors[] = 'خطأ: هذه الشريحة موجودة مسبقاً أو تتداخل مع شرائح أخرى';
        }
    }
}

// حذف شريحة
if (isset($_GET['delete_tier'])) {
    $id = clean($_GET['delete_tier']);
    $stmt = $conn->prepare("DELETE FROM commission_tiers WHERE id = ?");
    $stmt->execute([$id]);
    $success = 'تم حذف الشريحة';
    header("Location: dashboard.php?view=commission");
    exit;
}

// تحديث رصيد مستخدم
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_balance'])) {
    $user_id = clean($_POST['user_id']);
    $amount = clean($_POST['amount']);
    $action = clean($_POST['action']);
    
    if ($action == 'add') {
        $stmt = $conn->prepare("UPDATE wallet SET available_balance = available_balance + ? WHERE user_id = ?");
        $stmt->execute([$amount, $user_id]);
        logTransaction($user_id, 'admin_deposit', $amount, null, 'admin', 'إضافة رصيد من الأدمن');
        $success = 'تم إضافة الرصيد';
    } else {
        $stmt = $conn->prepare("UPDATE wallet SET available_balance = available_balance - ? WHERE user_id = ?");
        $stmt->execute([$amount, $user_id]);
        logTransaction($user_id, 'admin_deduct', $amount, null, 'admin', 'خصم رصيد من الأدمن');
        $success = 'تم خصم الرصيد';
    }
    header("Location: dashboard.php?view=users");
    exit;
}
// حذف منتج
if (isset($_GET['delete_product'])) {
    $product_id = clean($_GET['delete_product']);
    
    try {
        $conn->beginTransaction();
        
        // حذف الصور من السيرفر
        $stmt = $conn->prepare("SELECT image_path FROM store_product_images WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $images = $stmt->fetchAll();
        
        foreach ($images as $img) {
            if (file_exists($img['image_path'])) {
                unlink($img['image_path']);
            }
        }
        
        // حذف من قاعدة البيانات
        $stmt = $conn->prepare("DELETE FROM store_products WHERE id = ?");
        $stmt->execute([$product_id]);
        
        $conn->commit();
        $success = 'تم حذف المنتج';
    } catch(Exception $e) {
        $conn->rollBack();
        $errors[] = 'خطأ: ' . $e->getMessage();
    }
    
    header("Location: dashboard.php?view=store_products");
    exit;
}

// تعديل حالة منتج
if (isset($_GET['toggle_product_status'])) {
    $product_id = clean($_GET['toggle_product_status']);
    
    $stmt = $conn->prepare("UPDATE store_products SET status = IF(status = 'active', 'pending', 'active') WHERE id = ?");
    $stmt->execute([$product_id]);
    
    header("Location: dashboard.php?view=store_products");
    exit;
}

// إضافة/تعديل تصنيف
if (isset($_POST['save_category'])) {
    $cat_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
    $name = clean($_POST['name']);
    $slug = clean($_POST['slug']);
    $description = clean($_POST['description']);
    $icon = clean($_POST['icon']);
    $display_order = (int)$_POST['display_order'];
    
    if ($cat_id > 0) {
        // تحديث
        $stmt = $conn->prepare("UPDATE store_categories SET name = ?, slug = ?, description = ?, icon = ?, display_order = ? WHERE id = ?");
        $stmt->execute([$name, $slug, $description, $icon, $display_order, $cat_id]);
        $success = 'تم تحديث التصنيف';
    } else {
        // إضافة
        $stmt = $conn->prepare("INSERT INTO store_categories (name, slug, description, icon, display_order) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $slug, $description, $icon, $display_order]);
        $success = 'تم إضافة التصنيف';
    }
    
    header("Location: dashboard.php?view=store_categories");
    exit;
}

// حذف تصنيف
if (isset($_GET['delete_category'])) {
    $cat_id = clean($_GET['delete_category']);
    
    $stmt = $conn->prepare("DELETE FROM store_categories WHERE id = ?");
    $stmt->execute([$cat_id]);
    
    header("Location: dashboard.php?view=store_categories");
    exit;
}
if (isset($_POST['save_plan'])) {
    $plan_id = isset($_POST['plan_id']) ? (int)$_POST['plan_id'] : 0;
    $name = clean($_POST['name']);
    $price_monthly = (float)$_POST['price_monthly'];
    $price_yearly = (float)$_POST['price_yearly'];
    $description = clean($_POST['description']);
    $icon = clean($_POST['icon']);
    $color = clean($_POST['color']);
    $display_order = (int)$_POST['display_order'];
    
    if ($plan_id > 0) {
        $stmt = $conn->prepare("
            UPDATE subscription_plans 
            SET name = ?, price_monthly = ?, price_yearly = ?, description = ?, 
                icon = ?, color = ?, display_order = ? 
            WHERE id = ?
        ");
        $stmt->execute([$name, $price_monthly, $price_yearly, $description, $icon, $color, $display_order, $plan_id]);
        $success = 'تم تحديث الخطة';
    } else {
        $stmt = $conn->prepare("
            INSERT INTO subscription_plans 
            (name, price_monthly, price_yearly, description, icon, color, display_order) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$name, $price_monthly, $price_yearly, $description, $icon, $color, $display_order]);
        $success = 'تم إضافة الخطة';
    }
    
    header("Location: dashboard.php?view=subscription_plans");
    exit;
}

// حذف خطة
if (isset($_GET['delete_plan'])) {
    $plan_id = clean($_GET['delete_plan']);
    
    // التحقق من عدم وجود مشتركين
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM user_subscriptions WHERE plan_id = ? AND status = 'active'");
    $stmt->execute([$plan_id]);
    
    if ($stmt->fetch()['count'] > 0) {
        $errors[] = 'لا يمكن حذف خطة بها مشتركين نشطين';
    } else {
        $stmt = $conn->prepare("DELETE FROM subscription_plans WHERE id = ?");
        $stmt->execute([$plan_id]);
        $success = 'تم حذف الخطة';
    }
    
    header("Location: dashboard.php?view=subscription_plans");
    exit;
}

// إضافة/تعديل ميزة
if (isset($_POST['save_feature'])) {
    $feature_id = isset($_POST['feature_id']) ? (int)$_POST['feature_id'] : 0;
    $plan_id = (int)$_POST['plan_id'];
    $feature_key = clean($_POST['feature_key']);
    $feature_name = clean($_POST['feature_name']);
    $feature_value = clean($_POST['feature_value']);
    $display_order = (int)$_POST['display_order'];
    
    if ($feature_id > 0) {
        $stmt = $conn->prepare("
            UPDATE subscription_features 
            SET feature_key = ?, feature_name = ?, feature_value = ?, display_order = ? 
            WHERE id = ?
        ");
        $stmt->execute([$feature_key, $feature_name, $feature_value, $display_order, $feature_id]);
        $success = 'تم تحديث الميزة';
    } else {
        $stmt = $conn->prepare("
            INSERT INTO subscription_features 
            (plan_id, feature_key, feature_name, feature_value, display_order) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$plan_id, $feature_key, $feature_name, $feature_value, $display_order]);
        $success = 'تم إضافة الميزة';
    }
    
    header("Location: dashboard.php?view=subscription_plans");
    exit;
}

// حذف ميزة
if (isset($_GET['delete_feature'])) {
    $feature_id = clean($_GET['delete_feature']);
    $stmt = $conn->prepare("DELETE FROM subscription_features WHERE id = ?");
    $stmt->execute([$feature_id]);
    
    header("Location: dashboard.php?view=subscription_plans");
    exit;
}

// إلغاء اشتراك مستخدم
if (isset($_GET['cancel_subscription'])) {
    $subscription_id = clean($_GET['cancel_subscription']);
    
    $stmt = $conn->prepare("SELECT user_id FROM user_subscriptions WHERE id = ?");
    $stmt->execute([$subscription_id]);
    $sub = $stmt->fetch();
    
    $stmt = $conn->prepare("UPDATE user_subscriptions SET status = 'cancelled' WHERE id = ?");
    $stmt->execute([$subscription_id]);
    
    $stmt = $conn->prepare("UPDATE users SET current_plan_id = 1, subscription_expires_at = NULL WHERE id = ?");
    $stmt->execute([$sub['user_id']]);
    
    $success = 'تم إلغاء الاشتراك';
    header("Location: dashboard.php?view=subscription_users");
    exit;
}
// ==================== جلب البيانات ====================
// طلبات KYC
$stmt = $conn->query("
    SELECT 
        k.*,
        u.username,
        u.email,
        reviewer.username as reviewer_name
    FROM kyc_verifications k
    JOIN users u ON k.user_id = u.id
    LEFT JOIN users reviewer ON k.reviewed_by = reviewer.id
    ORDER BY 
        CASE k.status 
            WHEN 'pending' THEN 1 
            WHEN 'approved' THEN 2 
            WHEN 'rejected' THEN 3 
        END,
        k.submitted_at DESC
");
$kyc_requests = $stmt->fetchAll();
// منتجات المتجر
$stmt = $conn->query("
    SELECT 
        p.*,
        c.name as category_name,
        u.username as seller_name,
        (SELECT COUNT(*) FROM store_product_images WHERE product_id = p.id) as images_count
    FROM store_products p
    JOIN store_categories c ON p.category_id = c.id
    JOIN users u ON p.seller_id = u.id
    ORDER BY p.created_at DESC
");
$store_products = $stmt->fetchAll();

// التصنيفات
$stmt = $conn->query("SELECT * FROM store_categories ORDER BY display_order");
$store_categories = $stmt->fetchAll();

// طلبات المتجر
$stmt = $conn->query("
    SELECT 
        o.*,
        p.title as product_title,
        buyer.username as buyer_name,
        seller.username as seller_name
    FROM store_orders o
    JOIN store_products p ON o.product_id = p.id
    JOIN users buyer ON o.buyer_id = buyer.id
    JOIN users seller ON o.seller_id = seller.id
    ORDER BY o.created_at DESC
");
$store_orders = $stmt->fetchAll();
$stmt = $conn->query("SELECT * FROM store_commission_tiers ORDER BY min_price");
$store_commission_tiers = $stmt->fetchAll();

// عدد الطلبات المعلقة
$stmt = $conn->query("SELECT COUNT(*) as total FROM kyc_verifications WHERE status = 'pending'");
$pending_kyc_count = $stmt->fetch()['total'];
$view = isset($_GET['view']) ? clean($_GET['view']) : 'dashboard';
// إضافة/تعديل شريحة عمولة متجر
if (isset($_POST['save_store_commission'])) {
    $tier_id = isset($_POST['tier_id']) ? (int)$_POST['tier_id'] : 0;
    $min_price = (float)$_POST['min_price'];
    $max_price = (float)$_POST['max_price'];
    $commission_rate = (float)$_POST['commission_rate'];
    
    if ($tier_id > 0) {
        $stmt = $conn->prepare("UPDATE store_commission_tiers SET min_price = ?, max_price = ?, commission_rate = ? WHERE id = ?");
        $stmt->execute([$min_price, $max_price, $commission_rate, $tier_id]);
        $success = 'تم تحديث الشريحة';
    } else {
        $stmt = $conn->prepare("INSERT INTO store_commission_tiers (min_price, max_price, commission_rate) VALUES (?, ?, ?)");
        $stmt->execute([$min_price, $max_price, $commission_rate]);
        $success = 'تم إضافة الشريحة';
    }
    
    header("Location: dashboard.php?view=store_commissions");
    exit;
}

// حذف شريحة
if (isset($_GET['delete_store_tier'])) {
    $tier_id = clean($_GET['delete_store_tier']);
    $stmt = $conn->prepare("DELETE FROM store_commission_tiers WHERE id = ?");
    $stmt->execute([$tier_id]);
    
    header("Location: dashboard.php?view=store_commissions");
    exit;
}
// إحصائيات عامة
$stats = [];

$stmt = $conn->query("SELECT COUNT(*) as total FROM users");
$stats['total_users'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE status = 'active'");
$stats['active_users'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE status = 'suspended'");
$stats['suspended_users'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
$stats['new_users_month'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM auctions WHERE status = 'active'");
$stats['active_auctions'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM auctions WHERE status = 'completed'");
$stats['completed_auctions'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM auctions WHERE status = 'cancelled'");
$stats['cancelled_auctions'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM bids");
$stats['total_bids'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT SUM(current_price) as total FROM auctions WHERE status = 'completed'");
$stats['total_revenue'] = $stmt->fetch()['total'] ?? 0;

$stmt = $conn->query("SELECT SUM(amount) as total FROM transactions WHERE type = 'commission'");
$stats['commission_earned'] = $stmt->fetch()['total'] ?? 0;

$stmt = $conn->query("SELECT SUM(available_balance) as total FROM wallet");
$stats['total_wallet_balance'] = $stmt->fetch()['total'] ?? 0;

$stmt = $conn->query("SELECT SUM(frozen_balance) as total FROM wallet");
$stats['total_frozen_balance'] = $stmt->fetch()['total'] ?? 0;

// إحصائيات شهرية
$monthly_data = [];
for ($i = 11; $i >= 0; $i--) {
    $month_name = date('M', strtotime("-$i months"));
    $year = date('Y', strtotime("-$i months"));
    $month_num = date('m', strtotime("-$i months"));
    
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as auctions,
            COALESCE(SUM(current_price), 0) as revenue
        FROM auctions 
        WHERE status = 'completed' 
        AND YEAR(end_time) = ? 
        AND MONTH(end_time) = ?
    ");
    $stmt->execute([$year, $month_num]);
    $data = $stmt->fetch();
    
    $monthly_data[] = [
        'month' => $month_name,
        'auctions' => $data['auctions'] ?? 0,
        'revenue' => $data['revenue'] ?? 0
    ];
}

// جميع المستخدمين
$stmt = $conn->query("
    SELECT 
        u.*,
        COALESCE(w.available_balance, 0) as balance,
        COALESCE(w.frozen_balance, 0) as frozen,
        COUNT(DISTINCT a.id) as auctions_count,
        COUNT(DISTINCT b.id) as bids_count
    FROM users u
    LEFT JOIN wallet w ON u.id = w.user_id
    LEFT JOIN auctions a ON u.id = a.seller_id
    LEFT JOIN bids b ON u.id = b.user_id
    GROUP BY u.id
    ORDER BY u.created_at DESC
");
$all_users = $stmt->fetchAll();

// جميع المزادات
$stmt = $conn->query("
    SELECT 
        a.*,
        v.brand, v.model, v.year,
        u.username as seller_name,
        w.username as winner_name
    FROM auctions a
    JOIN vehicles v ON a.vehicle_id = v.id
    JOIN users u ON a.seller_id = u.id
    LEFT JOIN users w ON a.highest_bidder_id = w.id
    ORDER BY a.created_at DESC
");
$all_auctions = $stmt->fetchAll();

// آخر المعاملات
$stmt = $conn->query("
    SELECT 
        t.*,
        u.username
    FROM transactions t
    JOIN users u ON t.user_id = u.id
    ORDER BY t.created_at DESC
    LIMIT 50
");
$recent_transactions = $stmt->fetchAll();

// الشرائح السعرية
$stmt = $conn->query("SELECT * FROM commission_tiers ORDER BY min_price ASC");
$tiers = $stmt->fetchAll();

// أعلى البائعين
$stmt = $conn->query("
    SELECT 
        u.id, u.username, u.email,
        COUNT(a.id) as total_auctions,
        SUM(a.current_price) as total_sales
    FROM users u
    JOIN auctions a ON u.id = a.seller_id
    WHERE a.status = 'completed'
    GROUP BY u.id
    ORDER BY total_sales DESC
    LIMIT 10
");
$top_sellers = $stmt->fetchAll();

// أعلى المشترين
$stmt = $conn->query("
    SELECT 
        u.id, u.username, u.email,
        COUNT(b.id) as total_bids,
        SUM(b.bid_amount) as total_spent
    FROM users u
    JOIN bids b ON u.id = b.user_id
    WHERE b.status = 'won'
    GROUP BY u.id
    ORDER BY total_spent DESC
    LIMIT 10
");
$top_buyers = $stmt->fetchAll();

// آخر النشاطات
$stmt = $conn->query("
    (SELECT 'user_registered' as type, username as title, created_at as time, id as ref_id FROM users ORDER BY created_at DESC LIMIT 5)
    UNION ALL
    (SELECT 'auction_created' as type, CONCAT('مزاد جديد #', a.id) as title, a.created_at as time, a.id as ref_id FROM auctions a ORDER BY a.created_at DESC LIMIT 5)
    UNION ALL
    (SELECT 'bid_placed' as type, CONCAT('مزايدة على مزاد #', auction_id) as title, created_at as time, auction_id as ref_id FROM bids ORDER BY created_at DESC LIMIT 5)
    ORDER BY time DESC
    LIMIT 20
");
$activities = $stmt->fetchAll();
// جلب بيانات الاشتراكات
$stmt = $conn->query("SELECT * FROM subscription_plans ORDER BY display_order");
$subscription_plans = $stmt->fetchAll();

$stmt = $conn->query("
    SELECT 
        us.*,
        u.username,
        sp.name as plan_name,
        sp.color
    FROM user_subscriptions us
    JOIN users u ON us.user_id = u.id
    JOIN subscription_plans sp ON us.plan_id = sp.id
    ORDER BY us.created_at DESC
");
$user_subscriptions = $stmt->fetchAll();

// إحصائيات الاشتراكات
$stmt = $conn->query("SELECT COUNT(*) as total FROM user_subscriptions WHERE status = 'active'");
$stats['active_subscriptions'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT SUM(amount_paid) as total FROM user_subscriptions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
$stats['subscription_revenue_month'] = $stmt->fetch()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم الأدمن المتقدمة</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: #f5f7fa; 
            direction: rtl; 
        }
        
        /* Sidebar */
        .sidebar { 
            position: fixed; 
            right: 0; 
            top: 0; 
            width: 280px; 
            height: 100vh; 
            background: linear-gradient(180deg, #1e3a8a 0%, #1e293b 100%);
            color: white; 
            padding: 0; 
            overflow-y: auto; 
            z-index: 1000;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
        }
        .sidebar-header { 
            padding: 30px 20px; 
            background: rgba(0,0,0,0.2);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-header h2 { 
            font-size: 1.4rem; 
            margin-bottom: 5px; 
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .sidebar-header p { 
            font-size: 0.85rem; 
            color: #94a3b8; 
            opacity: 0.8;
        }
        .sidebar-menu { padding: 20px 0; }
        .menu-section { 
            padding: 15px 20px 10px; 
            font-size: 0.75rem; 
            text-transform: uppercase; 
            color: #94a3b8; 
            font-weight: 600;
            letter-spacing: 1px;
        }
        .menu-item { 
            padding: 14px 20px; 
            color: #cbd5e1; 
            text-decoration: none; 
            display: flex; 
            align-items: center; 
            gap: 15px; 
            transition: all 0.3s; 
            cursor: pointer;
            border-right: 3px solid transparent;
        }
        .menu-item:hover { 
            background: rgba(255,255,255,0.1); 
            color: white; 
            border-right-color: #3b82f6;
        }
        .menu-item.active { 
            background: rgba(59, 130, 246, 0.2); 
            color: white; 
            border-right-color: #3b82f6;
        }
        .menu-item i { 
            font-size: 1.2rem; 
            width: 25px;
            text-align: center;
        }
        .menu-item .badge { 
            margin-right: auto; 
            background: #ef4444; 
            color: white; 
            padding: 2px 8px; 
            border-radius: 10px; 
            font-size: 0.75rem;
        }
        
        /* Main Content */
        .main-content { 
            margin-right: 280px; 
            padding: 30px; 
            min-height: 100vh;
        }
        
        /* Header */
        .page-header { 
            background: white; 
            padding: 25px 30px; 
            border-radius: 15px; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.08); 
            margin-bottom: 30px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center;
        }
        .page-header h1 { 
            color: #1e293b; 
            font-size: 2rem;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .header-actions { 
            display: flex; 
            gap: 15px; 
        }
        .btn { 
            padding: 12px 24px; 
            border-radius: 10px; 
            text-decoration: none; 
            font-weight: 600; 
            transition: all 0.3s; 
            border: none; 
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary { 
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white; 
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }
        .btn-primary:hover { 
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }
        .btn-success { 
            background: #10b981; 
            color: white; 
        }
        .btn-success:hover { 
            background: #059669; 
        }
        .btn-danger { 
            background: #ef4444; 
            color: white; 
            font-size: 0.85rem; 
            padding: 8px 16px;
        }
        .btn-warning { 
            background: #f59e0b; 
            color: white; 
            font-size: 0.85rem; 
            padding: 8px 16px;
        }
        .btn-small { 
            padding: 6px 12px; 
            font-size: 0.85rem;
        }
        
        /* Stats Grid */
        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
            gap: 25px; 
            margin-bottom: 30px; 
        }
        .stat-card { 
            background: white; 
            padding: 25px; 
            border-radius: 15px; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.08); 
            position: relative; 
            overflow: hidden;
            transition: all 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        .stat-card::before { 
            content: ''; 
            position: absolute; 
            top: 0; 
            left: 0; 
            width: 4px; 
            height: 100%; 
        }
        .stat-card.blue::before { background: linear-gradient(180deg, #3b82f6, #2563eb); }
        .stat-card.green::before { background: linear-gradient(180deg, #10b981, #059669); }
        .stat-card.purple::before { background: linear-gradient(180deg, #a855f7, #9333ea); }
        .stat-card.orange::before { background: linear-gradient(180deg, #f59e0b, #d97706); }
        .stat-card.red::before { background: linear-gradient(180deg, #ef4444, #dc2626); }
        .stat-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: start; 
            margin-bottom: 15px; 
        }
        .stat-icon { 
            width: 55px; 
            height: 55px; 
            border-radius: 12px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-size: 1.6rem;
        }
        .stat-value { 
            font-size: 2.5rem; 
            font-weight: bold; 
            color: #1e293b; 
            margin-bottom: 5px;
            line-height: 1;
        }
        .stat-label { 
            color: #64748b; 
            font-size: 0.95rem;
            font-weight: 500;
        }
        .stat-change { 
            font-size: 0.85rem; 
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .stat-change.positive { color: #10b981; }
        .stat-change.negative { color: #ef4444; }
        
        /* Charts */
        .charts-grid { 
            display: grid; 
            grid-template-columns: 2fr 1fr; 
            gap: 25px; 
            margin-bottom: 30px; 
        }
        .chart-card { 
            background: white; 
            padding: 30px; 
            border-radius: 15px; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.08); 
        }
        .chart-card h3 { 
            color: #1e293b; 
            margin-bottom: 25px; 
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Tables */
        .content-section { 
            background: white; 
            padding: 30px; 
            border-radius: 15px; 
            box-shadow: 0 2px 15px rgba(0,0,0,0.08); 
            margin-bottom: 30px; 
            display: none; 
        }
        .content-section.active { 
            display: block; 
        }
        .section-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f1f5f9;
        }
        .section-header h3 { 
            color: #1e293b; 
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Search Bar */
        .search-bar {
            position: relative;
            max-width: 400px;
        }
        .search-bar input {
            width: 100%;
            padding: 12px 45px 12px 20px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 0.95rem;
        }
        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
        }
        
        table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        th, td { 
            padding: 15px; 
            text-align: right; 
            border-bottom: 1px solid #f1f5f9; 
        }
        th { 
            background: #f8fafc; 
            font-weight: 600; 
            color: #475569; 
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        td { 
            color: #64748b;
            font-size: 0.95rem;
        }
        tr:hover {
            background: #f8fafc;
        }
        
        /* Badges */
        .status-badge { 
            padding: 6px 14px; 
            border-radius: 20px; 
            font-size: 0.85rem; 
            font-weight: 600;
            display: inline-block;
        }
        .status-active { background: #d1fae5; color: #065f46; }
        .status-suspended { background: #fee2e2; color: #991b1b; }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-completed { background: #dbeafe; color: #1e40af; }
        .status-cancelled { background: #f3f4f6; color: #6b7280; }
        .status-expired { background: #fce7f3; color: #9f1239; }
        
        .tier-badge {
            padding: 8px 16px; 
            border-radius: 20px; 
            font-weight: 600; 
            font-size: 0.95rem;
        }
        .tier-low { background: #fef3c7; color: #92400e; }
        .tier-medium { background: #dbeafe; color: #1e40af; }
        .tier-high { background: #d1fae5; color: #065f46; }
        
        /* Alert */
        .alert { 
            padding: 16px 20px; 
            border-radius: 12px; 
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .alert-success { 
            background: #d1fae5; 
            color: #065f46; 
            border-right: 4px solid #10b981; 
        }
        .alert-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border-right: 4px solid #dc2626; 
        }
        
        /* Forms */
        .form-group { 
            margin-bottom: 20px; 
        }
        .form-group label { 
            display: block; 
            margin-bottom: 8px; 
            color: #1e293b; 
            font-weight: 600;
            font-size: 0.95rem;
        }
        .form-group input, .form-group select, .form-group textarea { 
            width: 100%; 
            padding: 12px 16px; 
            border: 2px solid #e2e8f0; 
            border-radius: 10px; 
            font-size: 1rem;
            transition: all 0.3s;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { 
            outline: none; 
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        .form-row { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 20px; 
        }
        
        /* Activity Feed */
        .activity-feed {
            max-height: 500px;
            overflow-y: auto;
        }
        .activity-item {
            padding: 15px;
            border-bottom: 1px solid #f1f5f9;
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s;
        }
        .activity-item:hover {
            background: #f8fafc;
        }
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }
        .activity-content h4 {
            color: #1e293b;
            font-size: 0.95rem;
            margin-bottom: 3px;
        }
        .activity-content p {
            color: #94a3b8;
            font-size: 0.85rem;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }
        .modal.active {
            display: flex;
        }
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .modal-header h3 {
            color: #1e293b;
            font-size: 1.3rem;
        }
        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #94a3b8;
        }
        
        @media (max-width: 768px) { 
            .sidebar { 
                width: 100%; 
                height: auto; 
                position: relative; 
            }
            .main-content { 
                margin-right: 0; 
            }
            .charts-grid, .form-row { 
                grid-template-columns: 1fr; 
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-shield-alt"></i> لوحة الأدمن</h2>
            <p>مرحباً، <?php echo htmlspecialchars($_SESSION['username']); ?></p>
        </div>
        <nav class="sidebar-menu">
            <div class="menu-section">القائمة الرئيسية</div>
            <div class="menu-item <?php echo $view == 'dashboard' ? 'active' : ''; ?>" onclick="showView('dashboard')">
                <i class="fas fa-chart-line"></i>
                <span>لوحة المعلومات</span>
            </div>
            
            <div class="menu-section">إدارة</div>
            <div class="menu-item <?php echo $view == 'kyc' ? 'active' : ''; ?>" onclick="showView('kyc')">
    <i class="fas fa-id-card"></i>
    <span>طلبات التحقق (KYC)</span>
    <?php if ($pending_kyc_count > 0): ?>
        <span class="badge"><?php echo $pending_kyc_count; ?></span>
    <?php endif; ?>
</div>
<div class="menu-item <?php echo $view == 'store_products' ? 'active' : ''; ?>" onclick="showView('store_products')">
    <i class="fas fa-store"></i>
    <span>إدارة المتجر</span>
</div>

<div class="menu-item <?php echo $view == 'store_categories' ? 'active' : ''; ?>" onclick="showView('store_categories')">
    <i class="fas fa-tags"></i>
    <span>تصنيفات المتجر</span>
</div>

<div class="menu-item <?php echo $view == 'store_orders' ? 'active' : ''; ?>" onclick="showView('store_orders')">
    <i class="fas fa-shopping-cart"></i>
    <span>طلبات المتجر</span>
</div>
<div class="menu-item <?php echo $view == 'store_commissions' ? 'active' : ''; ?>" onclick="showView('store_commissions')">
    <i class="fas fa-percent"></i>
    <span>عمولات المتجر</span>
</div>
            <div class="menu-item <?php echo $view == 'users' ? 'active' : ''; ?>" onclick="showView('users')">
                <i class="fas fa-users"></i>
                <span>المستخدمين</span>
                <span class="badge"><?php echo $stats['total_users']; ?></span>
            </div>
            <div class="menu-item <?php echo $view == 'auctions' ? 'active' : ''; ?>" onclick="showView('auctions')">
                <i class="fas fa-gavel"></i>
                <span>المزادات</span>
                <span class="badge"><?php echo $stats['active_auctions']; ?></span>
            </div>
            <div class="menu-item <?php echo $view == 'transactions' ? 'active' : ''; ?>" onclick="showView('transactions')">
                <i class="fas fa-exchange-alt"></i>
                <span>المعاملات</span>
</div><div class="menu-section">الإعدادات</div>
        <div class="menu-item <?php echo $view == 'commission' ? 'active' : ''; ?>" onclick="showView('commission')">
            <i class="fas fa-percentage"></i>
            <span>شرائح العمولات</span>
        </div>
        <div class="menu-item <?php echo $view == 'statistics' ? 'active' : ''; ?>" onclick="showView('statistics')">
            <i class="fas fa-chart-pie"></i>
            <span>الإحصائيات المتقدمة</span>
        </div>
        <div class="menu-item <?php echo $view == 'activities' ? 'active' : ''; ?>" onclick="showView('activities')">
            <i class="fas fa-history"></i>
            <span>سجل النشاطات</span>
        </div>
        
        <!-- في قسم الإعدادات -->
<div class="menu-section">الإعدادات</div>

<?php if ($view == 'commission'): ?>
<div class="menu-section">الاشتراكات</div>

<div class="menu-item <?php echo $view == 'subscription_plans' ? 'active' : ''; ?>" onclick="showView('subscription_plans')">
    <i class="fas fa-crown"></i>
    <span>خطط الاشتراكات</span>
</div>

<div class="menu-item <?php echo $view == 'subscription_users' ? 'active' : ''; ?>" onclick="showView('subscription_users')">
    <i class="fas fa-users-cog"></i>
    <span>اشتراكات المستخدمين</span>
</div>
    <!-- الشرائح الموجودة -->
<?php endif; ?>

<!-- ✅ إضافة زر الترجمات -->
<div class="menu-item <?php echo $view == 'translations_cache' ? 'active' : ''; ?>" onclick="showView('translations_cache')">
    <i class="fas fa-language"></i>
    <span>إدارة الترجمات</span>
</div>
        <div class="menu-section">أخرى</div>
        <a href="../index.php" class="menu-item">
            <i class="fas fa-home"></i>
            <span>الموقع الرئيسي</span>
        </a>
        <a href="../auth/logout.php" class="menu-item">
            <i class="fas fa-sign-out-alt"></i>
            <span>تسجيل الخروج</span>
        </a>
    </nav>
</aside>

<!-- Main Content -->
<main class="main-content">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1><i class="fas fa-tachometer-alt"></i> لوحة تحكم الأدمن المتقدمة</h1>
            <p style="color: #64748b; margin-top: 8px; font-size: 0.95rem;">إدارة كاملة للمنصة والمستخدمين والمزادات</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary" onclick="location.reload()">
                <i class="fas fa-sync-alt"></i> تحديث
            </button>
        </div>
    </div>

    <!-- Alerts -->
    <?php if ($msg = getMessage()): ?>
        <div class="alert alert-<?php echo $msg['type']; ?>">
            <i class="fas fa-<?php echo $msg['type'] == 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo $msg['text']; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle"></i>
            <ul style="margin: 0; padding-right: 20px;">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <?php echo $success; ?>
        </div>
    <?php endif; ?>

    <!-- ==================== Dashboard View ==================== -->
    <div id="dashboard" class="content-section <?php echo $view == 'dashboard' ? 'active' : ''; ?>">
        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card blue">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['total_users']); ?></div>
                        <div class="stat-label">إجمالي المستخدمين</div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +<?php echo $stats['new_users_month']; ?> هذا الشهر
                        </div>
                    </div>
                    <div class="stat-icon" style="background: #dbeafe; color: #2563eb;">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card green">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['active_auctions']); ?></div>
                        <div class="stat-label">مزادات نشطة حالياً</div>
                        <div class="stat-change">
                            إجمالي: <?php echo $stats['completed_auctions']; ?> مكتمل
                        </div>
                    </div>
                    <div class="stat-icon" style="background: #d1fae5; color: #10b981;">
                        <i class="fas fa-fire"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card purple">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['total_bids']); ?></div>
                        <div class="stat-label">إجمالي المزايدات</div>
                        <div class="stat-change">
                            على جميع المزادات
                        </div>
                    </div>
                    <div class="stat-icon" style="background: #e9d5ff; color: #a855f7;">
                        <i class="fas fa-gavel"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card orange">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['commission_earned'], 0); ?>$</div>
                        <div class="stat-label">أرباح العمولات</div>
                        <div class="stat-change positive">
                            <i class="fas fa-dollar-sign"></i>
                            من <?php echo number_format($stats['total_revenue'], 0); ?>$ مبيعات
                        </div>
                    </div>
                    <div class="stat-icon" style="background: #fef3c7; color: #f59e0b;">
                        <i class="fas fa-chart-line"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card red">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?php echo number_format($stats['total_wallet_balance'], 0); ?>$</div>
                        <div class="stat-label">إجمالي أرصدة المحافظ</div>
                        <div class="stat-change">
                            محجوز: <?php echo number_format($stats['total_frozen_balance'], 0); ?>$
                        </div>
                    </div>
                    <div class="stat-icon" style="background: #fee2e2; color: #ef4444;">
                        <i class="fas fa-wallet"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card blue">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?php echo $stats['active_users']; ?></div>
                        <div class="stat-label">مستخدمين نشطين</div>
                        <div class="stat-change negative">
                            <i class="fas fa-ban"></i>
                            <?php echo $stats['suspended_users']; ?> موقوفين
                        </div>
                    </div>
                    <div class="stat-icon" style="background: #dbeafe; color: #2563eb;">
                        <i class="fas fa-user-check"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="charts-grid">
            <div class="chart-card">
                <h3><i class="fas fa-chart-area"></i> إيرادات آخر 12 شهر</h3>
                <canvas id="revenueChart" style="max-height: 300px;"></canvas>
            </div>

            <div class="chart-card">
                <h3><i class="fas fa-chart-pie"></i> توزيع المزادات</h3>
                <canvas id="auctionsChart" style="max-height: 300px;"></canvas>
            </div>
        </div>

        <!-- Top Users -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 30px;">
            <div class="chart-card">
                <h3><i class="fas fa-trophy"></i> أعلى البائعين</h3>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>المستخدم</th>
                                <th>المزادات</th>
                                <th>المبيعات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($top_sellers, 0, 5) as $index => $seller): ?>
                                <tr>
                                    <td><strong><?php echo $index + 1; ?></strong></td>
                                    <td><strong><?php echo htmlspecialchars($seller['username']); ?></strong></td>
                                    <td><?php echo $seller['total_auctions']; ?></td>
                                    <td><strong style="color: #10b981;"><?php echo number_format($seller['total_sales'], 0); ?>$</strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="chart-card">
                <h3><i class="fas fa-medal"></i> أعلى المشترين</h3>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>المستخدم</th>
                                <th>المزايدات</th>
                                <th>الإنفاق</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($top_buyers, 0, 5) as $index => $buyer): ?>
                                <tr>
                                    <td><strong><?php echo $index + 1; ?></strong></td>
                                    <td><strong><?php echo htmlspecialchars($buyer['username']); ?></strong></td>
                                    <td><?php echo $buyer['total_bids']; ?></td>
                                    <td><strong style="color: #2563eb;"><?php echo number_format($buyer['total_spent'], 0); ?>$</strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================== Users View ==================== -->
    <div id="users" class="content-section <?php echo $view == 'users' ? 'active' : ''; ?>">
        <div class="section-header">
            <h3><i class="fas fa-users"></i> إدارة المستخدمين</h3>
            <div class="search-bar">
                <input type="text" id="searchUsers" placeholder="بحث عن مستخدم..." onkeyup="filterTable('usersTable', 'searchUsers')">
                <i class="fas fa-search"></i>
            </div>
        </div>
        
        <div style="overflow-x: auto;">
            <table id="usersTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>الاسم</th>
                        <th>البريد الإلكتروني</th>
                        <th>الهاتف</th>
                        <th>الرصيد</th>
                        <th>محجوز</th>
                        <th>المزادات</th>
                        <th>المزايدات</th>
                        <th>الحالة</th>
                        <th>التسجيل</th>
                        <th>إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($all_users as $user): ?>
                        <tr>
                            <td><strong>#<?php echo $user['id']; ?></strong></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 35px; height: 35px; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                        <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                                    </div>
                                    <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['phone']); ?></td>
                            <td><strong style="color: #10b981;"><?php echo number_format($user['balance'], 2); ?>$</strong></td>
                            <td><strong style="color: #f59e0b;"><?php echo number_format($user['frozen'], 2); ?>$</strong></td>
                            <td><?php echo $user['auctions_count']; ?></td>
                            <td><?php echo $user['bids_count']; ?></td>
                            <td>
                                <?php if ($user['status'] == 'active'): ?>
                                    <span class="status-badge status-active"><i class="fas fa-check-circle"></i> نشط</span>
                                <?php elseif ($user['status'] == 'suspended'): ?>
                                    <span class="status-badge status-suspended"><i class="fas fa-ban"></i> موقوف</span>
                                <?php else: ?>
                                    <span class="status-badge status-pending"><i class="fas fa-clock"></i> معلق</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                            <td>
                                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                    <button class="btn btn-primary btn-small" onclick="openBalanceModal(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')">
                                        <i class="fas fa-wallet"></i>
                                    </button>
                                    <?php if ($user['status'] == 'active'): ?>
                                        <a href="?suspend_user=<?php echo $user['id']; ?>" class="btn btn-warning btn-small" onclick="return confirm('تعطيل هذا المستخدم؟')">
                                            <i class="fas fa-ban"></i>
                                        </a>
                                    <?php else: ?>
                                        <a href="?activate_user=<?php echo $user['id']; ?>" class="btn btn-success btn-small">
                                            <i class="fas fa-check"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<!-- ==================== Auctions View ==================== -->
<div id="auctions" class="content-section <?php echo $view == 'auctions' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-gavel"></i> إدارة المزادات</h3>
        <div class="search-bar">
            <input type="text" id="searchAuctions" placeholder="بحث عن مزاد..." onkeyup="filterTable('auctionsTable', 'searchAuctions')">
            <i class="fas fa-search"></i>
        </div>
    </div>
    
    <div style="overflow-x: auto;">
        <table id="auctionsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>السيارة</th>
                    <th>البائع</th>
                    <th>السعر الابتدائي</th>
                    <th>السعر الحالي</th>
                    <th>الحد الأدنى للزيادة</th>
                    <th>المزايدات</th>
                    <th>الفائز</th>
                    <th>الحالة</th>
                    <th>الانتهاء</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($all_auctions as $auction): ?>
                    <tr>
                        <td><strong>#<?php echo $auction['id']; ?></strong></td>
                        <td>
                            <strong><?php echo htmlspecialchars($auction['brand'] . ' ' . $auction['model']); ?></strong>
                            <br>
                            <small style="color: #94a3b8;"><?php echo $auction['year']; ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($auction['seller_name']); ?></td>
                        <td><?php echo number_format($auction['starting_price'], 0); ?>$</td>
                        <td><strong style="color: #2563eb;"><?php echo number_format($auction['current_price'], 0); ?>$</strong></td>
                        <td><span class="status-badge status-pending"><?php echo number_format($auction['min_bid_increment'] ?? 50, 0); ?>$</span></td>
                        <td><span class="status-badge status-active"><?php echo $auction['total_bids']; ?></span></td>
                        <td><?php echo $auction['winner_name'] ? htmlspecialchars($auction['winner_name']) : '-'; ?></td>
                        <td>
                            <?php if ($auction['status'] == 'active'): ?>
                                <span class="status-badge status-active"><i class="fas fa-circle"></i> نشط</span>
                            <?php elseif ($auction['status'] == 'completed'): ?>
                                <span class="status-badge status-completed"><i class="fas fa-check-circle"></i> مكتمل</span>
                            <?php elseif ($auction['status'] == 'cancelled'): ?>
                                <span class="status-badge status-cancelled"><i class="fas fa-times-circle"></i> ملغي</span>
                            <?php else: ?>
                                <span class="status-badge status-expired"><i class="fas fa-hourglass-end"></i> منتهي</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php 
                            $time_left = strtotime($auction['end_time']) - time();
                            if ($time_left > 0) {
                                $hours = floor($time_left / 3600);
                                $minutes = floor(($time_left % 3600) / 60);
                                echo "<span style='color: #10b981;'>$hours ساعة و $minutes دقيقة</span>";
                            } else {
                                echo "<span style='color: #ef4444;'>انتهى</span>";
                            }
                            ?>
                            <br>
                            <small style="color: #94a3b8;"><?php echo date('Y-m-d H:i', strtotime($auction['end_time'])); ?></small>
                        </td>
                        <td>
                            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                <a href="../auction-details.php?id=<?php echo $auction['id']; ?>" class="btn btn-primary btn-small" target="_blank" title="عرض">
                                    <i class="fas fa-eye"></i>
                                </a>
                                
                                <?php if ($auction['status'] == 'active'): ?>
                                    <button class="btn btn-warning btn-small" onclick="openEditAuctionModal(<?php echo htmlspecialchars(json_encode($auction)); ?>)" title="تعديل">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    
                                    <a href="?force_end_auction=<?php echo $auction['id']; ?>" class="btn btn-danger btn-small" onclick="return confirm('إنهاء المزاد فوراً؟')" title="إنهاء فوري">
                                        <i class="fas fa-stop-circle"></i>
                                    </a>
                                    
                                    <a href="?cancel_auction=<?php echo $auction['id']; ?>" class="btn btn-danger btn-small" onclick="return confirm('إلغاء المزاد نهائياً؟')" title="إلغاء">
                                        <i class="fas fa-times"></i>
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($auction['status'] == 'expired'): ?>
                                    <button class="btn btn-success btn-small" onclick="openReactivateModal(<?php echo $auction['id']; ?>)" title="إعادة تفعيل">
                                        <i class="fas fa-redo"></i>
                                    </button>
                                <?php endif; ?>
                                
                                <?php if (in_array($auction['status'], ['expired', 'cancelled']) && $auction['highest_bidder_id']): ?>
                                    <a href="?manual_complete=<?php echo $auction['id']; ?>" class="btn btn-success btn-small" onclick="return confirm('تحديد هذا المزاد كمكتمل يدوياً؟')" title="إكمال يدوي">
                                        <i class="fas fa-check-double"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>    <!-- ==================== Transactions View ==================== -->
    <div id="transactions" class="content-section <?php echo $view == 'transactions' ? 'active' : ''; ?>">
        <div class="section-header">
            <h3><i class="fas fa-exchange-alt"></i> سجل المعاملات</h3>
            <div class="search-bar">
                <input type="text" id="searchTransactions" placeholder="بحث في المعاملات..." onkeyup="filterTable('transactionsTable', 'searchTransactions')">
                <i class="fas fa-search"></i>
            </div>
        </div>
        
        <div style="overflow-x: auto;">
            <table id="transactionsTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>المستخدم</th>
                        <th>النوع</th>
                        <th>المبلغ</th>
                        <th>الوصف</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_transactions as $trans): ?>
                        <tr>
                            <td><strong>#<?php echo $trans['id']; ?></strong></td>
                            <td><?php echo htmlspecialchars($trans['username']); ?></td>
                            <td>
                                <?php
                                $types = [
                                    'deposit' => ['إيداع', 'success'],
                                    'bid_freeze' => ['حجز مزايدة', 'pending'],
                                    'bid_release' => ['إلغاء حجز', 'active'],
                                    'bid_deduct' => ['خصم مزايدة', 'suspended'],
                                    'commission' => ['عمولة', 'completed'],
                                    'admin_deposit' => ['إيداع أدمن', 'active'],
                                    'admin_deduct' => ['خصم أدمن', 'suspended']
                                ];
                                $type_info = $types[$trans['type']] ?? ['معاملة', 'pending'];
                                ?>
                                <span class="status-badge status-<?php echo $type_info[1]; ?>">
                                    <?php echo $type_info[0]; ?>
                                </span>
                            </td>
                            <td>
                                <strong style="color: <?php echo in_array($trans['type'], ['deposit', 'admin_deposit', 'bid_release']) ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo in_array($trans['type'], ['deposit', 'admin_deposit', 'bid_release']) ? '+' : '-'; ?>
                                    <?php echo number_format($trans['amount'], 2); ?>$
                                </strong>
                            </td>
                            <td><?php echo htmlspecialchars($trans['description']); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($trans['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ==================== Commission Tiers View ==================== -->
    <div id="commission" class="content-section <?php echo $view == 'commission' ? 'active' : ''; ?>">
        <div class="section-header">
            <h3><i class="fas fa-percentage"></i> شرائح العمولات</h3>
        </div>

        <div style="background: #f8fafc; padding: 30px; border-radius: 12px; margin-bottom: 30px;">
            <h4 style="margin-bottom: 20px; color: #1e293b;"><i class="fas fa-plus-circle"></i> إضافة شريحة جديدة</h4>
            <form method="POST" action="">
                <div class="form-row">
                    <div class="form-group">
                        <label>السعر الأدنى ($)</label>
                        <input type="number" name="min_price" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>السعر الأعلى ($)</label>
                        <input type="number" name="max_price" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>نسبة العمولة (%)</label>
                        <input type="number" name="commission_rate" step="0.01" min="0" max="100" required>
                    </div>
                </div>
                <button type="submit" name="add_tier" class="btn btn-success">
                    <i class="fas fa-plus"></i> إضافة الشريحة
                </button>
            </form>
        </div>

        <?php if (empty($tiers)): ?>
            <div style="text-align: center; padding: 60px 20px; background: white; border-radius: 15px;">
                <i class="fas fa-inbox" style="font-size: 4rem; color: #cbd5e1; margin-bottom: 20px;"></i>
                <h3 style="color: #64748b;">لا توجد شرائح محددة</h3>
            </div>
        <?php else: ?>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>النطاق السعري</th>
                            <th>نسبة العمولة</th>
                            <th>مثال توضيحي</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tiers as $tier): ?>
                            <tr>
                                <td>
                                    <strong style="color: #2563eb;"><?php echo number_format($tier['min_price'], 0); ?>$</strong>
                                    <i class="fas fa-arrow-left" style="color: #cbd5e1; margin: 0 8px;"></i>
                                    <strong style="color: #10b981;"><?php echo number_format($tier['max_price'], 0); ?>$</strong>
                                </td>
                                <td>
                                    <span class="tier-badge <?php 
                                        echo $tier['commission_rate'] >= 8 ? 'tier-low' : 
                                            ($tier['commission_rate'] >= 5 ? 'tier-medium' : 'tier-high'); 
                                    ?>">
                                        <i class="fas fa-percentage"></i> <?php echo $tier['commission_rate']; ?>%
                                    </span>
                                </td>
                                <td style="color: #64748b; font-size: 0.9rem;">
                                    <?php 
                                    $example_price = ($tier['min_price'] + $tier['max_price']) / 2;
                                    $example_commission = $example_price * ($tier['commission_rate'] / 100);
                                    $seller_gets = $example_price - $example_commission;
                                    ?>
                                    <div>سعر <strong><?php echo number_format($example_price, 0); ?>$</strong></div>
                                    <div style="font-size: 0.85rem; margin-top: 3px;">
                                        عمولة: <span style="color: #ef4444;"><?php echo number_format($example_commission, 2); ?>$</span> |
                                        البائع: <span style="color: #10b981;"><?php echo number_format($seller_gets, 2); ?>$</span>
                                    </div>
                                </td>
                                <td>
                                    <a href="?delete_tier=<?php echo $tier['id']; ?>" 
                                       class="btn btn-danger btn-small"
                                       onclick="return confirm('هل أنت متأكد من الحذف؟')">
                                        <i class="fas fa-trash"></i> حذف
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- ==================== Statistics View ==================== -->
    <div id="statistics" class="content-section <?php echo $view == 'statistics' ? 'active' : ''; ?>">
        <div class="section-header">
            <h3><i class="fas fa-chart-bar"></i> الإحصائيات المتقدمة</h3>
        </div>

        <div class="charts-grid" style="grid-template-columns: 1fr 1fr; margin-bottom: 30px;">
            <div class="chart-card">
                <h3><i class="fas fa-dollar-sign"></i> توزيع الإيرادات</h3>
                <canvas id="revenueBreakdownChart"></canvas>
            </div>

            <div class="chart-card">
                <h3><i class="fas fa-users"></i> نمو المستخدمين</h3>
                <canvas id="usersGrowthChart"></canvas>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px;">
            <div class="chart-card">
                <h3><i class="fas fa-trophy"></i> أعلى 10 بائعين</h3>
                <div style="max-height: 400px; overflow-y: auto;">
                    <?php foreach ($top_sellers as $index => $seller): ?>
                        <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px; border-bottom: 1px solid #f1f5f9;">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <span style="font-size: 1.2rem; font-weight: bold; color: #94a3b8;">#<?php echo $index + 1; ?></span>
                                <div>
                                    <div style="font-weight: 600; color: #1e293b;"><?php echo htmlspecialchars($seller['username']); ?></div>
<div style="font-size: 0.85rem; color: #94a3b8;"><?php echo $seller['total_auctions']; ?> مزاد</div>
</div>
</div>
<strong style="color: #10b981;"><?php echo number_format($seller['total_sales'], 0); ?>$</strong>
</div>
<?php endforeach; ?>
</div>
</div>
            <div class="chart-card">
                <h3><i class="fas fa-medal"></i> أعلى 10 مشترين</h3>
                <div style="max-height: 400px; overflow-y: auto;">
                    <?php foreach ($top_buyers as $index => $buyer): ?>
                        <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px; border-bottom: 1px solid #f1f5f9;">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <span style="font-size: 1.2rem; font-weight: bold; color: #94a3b8;">#<?php echo $index + 1; ?></span>
                                <div>
                                    <div style="font-weight: 600; color: #1e293b;"><?php echo htmlspecialchars($buyer['username']); ?></div>
                                    <div style="font-size: 0.85rem; color: #94a3b8;"><?php echo $buyer['total_bids']; ?> مزايدة</div>
                                </div>
                            </div>
                            <strong style="color: #2563eb;"><?php echo number_format($buyer['total_spent'], 0); ?>$</strong>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================== Activities View ==================== -->
    <div id="activities" class="content-section <?php echo $view == 'activities' ? 'active' : ''; ?>">
        <div class="section-header">
            <h3><i class="fas fa-history"></i> سجل النشاطات</h3>
        </div>

        <div class="chart-card">
            <div class="activity-feed">
                <?php foreach ($activities as $activity): ?>
                    <div class="activity-item">
                        <?php
                        $icons = [
                            'user_registered' => ['fas fa-user-plus', '#3b82f6'],
                            'auction_created' => ['fas fa-gavel', '#10b981'],
                            'bid_placed' => ['fas fa-hand-holding-usd', '#f59e0b']
                        ];
                        $icon_data = $icons[$activity['type']] ?? ['fas fa-circle', '#94a3b8'];
                        ?>
                        <div class="activity-icon" style="background: <?php echo $icon_data[1]; ?>20; color: <?php echo $icon_data[1]; ?>;">
                            <i class="<?php echo $icon_data[0]; ?>"></i>
                        </div>
                        <div class="activity-content">
                            <h4><?php echo htmlspecialchars($activity['title']); ?></h4>
                            <p>
                                <?php
                                $time_diff = time() - strtotime($activity['time']);
                                if ($time_diff < 60) echo 'منذ لحظات';
                                elseif ($time_diff < 3600) echo 'منذ ' . floor($time_diff / 60) . ' دقيقة';
                                elseif ($time_diff < 86400) echo 'منذ ' . floor($time_diff / 3600) . ' ساعة';
                                else echo 'منذ ' . floor($time_diff / 86400) . ' يوم';
                                ?>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <!-- Edit Auction Modal -->
<div id="editAuctionModal" class="modal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h3><i class="fas fa-edit"></i> تعديل المزاد</h3>
            <button class="modal-close" onclick="closeEditAuctionModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="auction_id" id="edit_auction_id">
            
            <div class="form-group">
                <label>السيارة</label>
                <input type="text" id="edit_auction_vehicle" disabled style="background: #f1f5f9;">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>السعر الابتدائي ($)</label>
                    <input type="number" name="starting_price" id="edit_starting_price" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label>الحد الأدنى للزيادة ($)</label>
                    <input type="number" name="min_bid_increment" id="edit_min_bid_increment" step="0.01" required>
                    <small style="color: #64748b; font-size: 0.85rem;">الحد الأدنى لكل مزايدة</small>
                </div>
            </div>
            
            <div class="form-group">
                <label>وقت الانتهاء</label>
                <input type="datetime-local" name="end_time" id="edit_end_time" required>
            </div>
            
            <div style="background: #fef3c7; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                <p style="color: #92400e; font-size: 0.9rem; margin: 0;">
                    <i class="fas fa-exclamation-triangle"></i> 
                    <strong>تحذير:</strong> تغيير السعر الابتدائي قد يؤثر على المزايدات الحالية
                </p>
            </div>
            
            <button type="submit" name="edit_auction" class="btn btn-primary">
                <i class="fas fa-save"></i> حفظ التعديلات
            </button>
        </form>
    </div>
</div>

<!-- Reactivate Auction Modal -->
<div id="reactivateModal" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <div class="modal-header">
            <h3><i class="fas fa-redo"></i> إعادة تفعيل المزاد</h3>
            <button class="modal-close" onclick="closeReactivateModal()">&times;</button>
        </div>
        <div id="reactivate_auction_id_holder"></div>
        <p style="color: #64748b; margin-bottom: 20px;">اختر المدة التي تريد إعادة تفعيل المزاد لها:</p>
        
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
            <button class="btn btn-primary" onclick="reactivateAuction(6)">
                <i class="fas fa-clock"></i> 6 ساعات
            </button>
            <button class="btn btn-primary" onclick="reactivateAuction(12)">
                <i class="fas fa-clock"></i> 12 ساعة
            </button>
            <button class="btn btn-primary" onclick="reactivateAuction(24)">
                <i class="fas fa-clock"></i> 24 ساعة
            </button>
            <button class="btn btn-primary" onclick="reactivateAuction(48)">
                <i class="fas fa-clock"></i> 48 ساعة
            </button>
        </div>
        
        <div style="margin-top: 20px;">
            <label style="display: block; margin-bottom: 8px; color: #1e293b; font-weight: 600;">أو أدخل عدد الساعات:</label>
            <div style="display: flex; gap: 10px;">
                <input type="number" id="custom_hours" placeholder="عدد الساعات" style="flex: 1; padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px;">
                <button class="btn btn-success" onclick="reactivateAuction(document.getElementById('custom_hours').value)">
                    <i class="fas fa-check"></i> تطبيق
                </button>
            </div>
        </div>
    </div>
</div>
<!-- ==================== KYC View ==================== -->
<div id="kyc" class="content-section <?php echo $view == 'kyc' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-id-card"></i> طلبات التحقق من الهوية</h3>
        <div style="color: #64748b;">
            <strong><?php echo $pending_kyc_count; ?></strong> طلب قيد الانتظار
        </div>
    </div>
    
    <?php if (empty($kyc_requests)): ?>
        <div style="text-align: center; padding: 60px 20px; background: white; border-radius: 15px;">
            <i class="fas fa-inbox" style="font-size: 4rem; color: #cbd5e1; margin-bottom: 20px;"></i>
            <h3 style="color: #64748b;">لا توجد طلبات</h3>
        </div>
    <?php else: ?>
        <div style="display: grid; gap: 20px;">
            <?php foreach ($kyc_requests as $kyc): ?>
                <div style="background: white; border-radius: 15px; padding: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); 
                            <?php echo $kyc['status'] == 'pending' ? 'border-right: 4px solid #f59e0b;' : ''; ?>">
                    <div style="display: grid; grid-template-columns: 1fr 2fr 1fr; gap: 25px; align-items: start;">
                        <!-- معلومات المستخدم -->
                        <div>
                            <h4 style="color: #1e293b; margin-bottom: 10px; font-size: 1.1rem;">
                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($kyc['username']); ?>
                            </h4>
                            <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 5px;">
                                <strong>البريد:</strong> <?php echo htmlspecialchars($kyc['email']); ?>
                            </p>
                            <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 5px;">
                                <strong>الاسم الكامل:</strong> <?php echo htmlspecialchars($kyc['full_name']); ?>
                            </p>
                            <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 5px;">
                                <strong>رقم الهوية:</strong> <?php echo htmlspecialchars($kyc['id_number']); ?>
                            </p>
                            <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 10px;">
                                <strong>تاريخ الرفع:</strong> <?php echo date('Y-m-d H:i', strtotime($kyc['submitted_at'])); ?>
                            </p>
                            
                            <?php if ($kyc['status'] == 'pending'): ?>
                                <span class="status-badge status-pending">
                                    <i class="fas fa-clock"></i> قيد المراجعة
                                </span>
                            <?php elseif ($kyc['status'] == 'approved'): ?>
                                <span class="status-badge status-active">
                                    <i class="fas fa-check-circle"></i> موافق عليه
                                </span>
                                <p style="color: #64748b; font-size: 0.85rem; margin-top: 5px;">
                                    بواسطة: <?php echo htmlspecialchars($kyc['reviewer_name']); ?>
                                </p>
                            <?php else: ?>
                                <span class="status-badge status-suspended">
                                    <i class="fas fa-times-circle"></i> مرفوض
                                </span>
                                <?php if ($kyc['rejection_reason']): ?>
                                    <p style="color: #991b1b; font-size: 0.85rem; margin-top: 5px; background: #fee2e2; padding: 8px; border-radius: 6px;">
                                        <strong>السبب:</strong> <?php echo htmlspecialchars($kyc['rejection_reason']); ?>
                                    </p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        
                        <!-- الصور -->
                        <div>
                            <h5 style="color: #1e293b; margin-bottom: 15px;">الوثائق المرفوعة:</h5>
                            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                                <div>
                                    <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 5px;">الهوية (أمامي)</p>
                                    <a href="../<?php echo $kyc['id_front_image']; ?>" target="_blank">
                                        <img src="../<?php echo $kyc['id_front_image']; ?>" 
                                             style="width: 100%; height: 120px; object-fit: cover; border-radius: 8px; border: 2px solid #e2e8f0; cursor: pointer;"
                                             onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22><text x=%2250%%22 y=%2250%%22 text-anchor=%22middle%22 dy=%22.3em%22>PDF</text></svg>'">
                                    </a>
                                </div>
                                <div>
                                    <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 5px;">الهوية (خلفي)</p>
                                    <a href="../<?php echo $kyc['id_back_image']; ?>" target="_blank">
                                        <img src="../<?php echo $kyc['id_back_image']; ?>" 
                                             style="width: 100%; height: 120px; object-fit: cover; border-radius: 8px; border: 2px solid #e2e8f0; cursor: pointer;"
                                             onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22><text x=%2250%%22 y=%2250%%22 text-anchor=%22middle%22 dy=%22.3em%22>PDF</text></svg>'">
                                    </a>
                                </div>
                                <div>
                                    <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 5px;">الصورة الشخصية</p>
                                    <a href="../<?php echo $kyc['selfie_image']; ?>" target="_blank">
                                        <img src="../<?php echo $kyc['selfie_image']; ?>" 
                                             style="width: 100%; height: 120px; object-fit: cover; border-radius: 8px; border: 2px solid #e2e8f0; cursor: pointer;">
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- الإجراءات -->
                        <div>
                            <?php if ($kyc['status'] == 'pending'): ?>
                                <h5 style="color: #1e293b; margin-bottom: 15px;">الإجراءات:</h5>
                                <div style="display: flex; flex-direction: column; gap: 10px;">
                                    <a href="?approve_kyc=<?php echo $kyc['id']; ?>" 
                                       class="btn btn-success"
                                       onclick="return confirm('الموافقة على هذا الطلب؟')"
                                       style="text-align: center; padding: 12px;">
                                        <i class="fas fa-check"></i> الموافقة
                                    </a>
                                    
                                    <button class="btn btn-danger" 
                                            onclick="openRejectModal(<?php echo $kyc['id']; ?>)"
                                            style="padding: 12px;">
                                        <i class="fas fa-times"></i> الرفض
                                    </button>
                                </div>
                            <?php else: ?>
                                <p style="color: #64748b; font-size: 0.9rem; text-align: center;">
                                    تمت المراجعة في:<br>
                                    <?php echo date('Y-m-d H:i', strtotime($kyc['reviewed_at'])); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Reject KYC Modal -->
<div id="rejectKycModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-times-circle"></i> رفض طلب التحقق</h3>
            <button class="modal-close" onclick="closeRejectKycModal()">&times;</button>
        </div>
        <div id="reject_kyc_id_holder"></div>
        <div class="form-group">
            <label>سبب الرفض:</label>
            <textarea id="rejection_reason" style="width: 100%; padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; min-height: 100px;"></textarea>
        </div>
        <button class="btn btn-danger" onclick="submitRejection()">
            <i class="fas fa-times"></i> تأكيد الرفض
        </button>
    </div>
</div>
<!-- ==================== Store Products View ==================== -->
<div id="store_products" class="content-section <?php echo $view == 'store_products' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-store"></i> إدارة المتجر</h3>
        <div>
            <span style="color: #64748b;">إجمالي المنتجات: <strong><?php echo count($store_products); ?></strong></span>
        </div>
    </div>
    
    <?php if (empty($store_products)): ?>
        <div style="text-align: center; padding: 60px 20px; background: white; border-radius: 15px;">
            <i class="fas fa-box-open" style="font-size: 4rem; color: #cbd5e1; margin-bottom: 20px;"></i>
            <h3 style="color: #64748b;">لا توجد منتجات</h3>
        </div>
    <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>الصورة</th>
                        <th>المنتج</th>
                        <th>التصنيف</th>
                        <th>البائع</th>
                        <th>السعر</th>
                        <th>الكمية</th>
                        <th>الحالة</th>
                        <th>المشاهدات</th>
                        <th>إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($store_products as $product): ?>
                        <tr>
                            <td><?php echo $product['id']; ?></td>
                            <td>
                                <?php
                                $stmt = $conn->prepare("SELECT image_path FROM store_product_images WHERE product_id = ? AND is_primary = TRUE LIMIT 1");
                                $stmt->execute([$product['id']]);
                                $img = $stmt->fetch();
                                if ($img):
                                ?>
                                    <img src="../<?php echo $img['image_path']; ?>" style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;">
                                <?php else: ?>
                                    <div style="width: 60px; height: 60px; background: #f1f5f9; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-image" style="color: #cbd5e1;"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($product['title']); ?></strong>
                            </td>
                            <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                            <td><?php echo htmlspecialchars($product['seller_name']); ?></td>
                            <td><strong style="color: #10b981;"><?php echo number_format($product['price'], 2); ?>$</strong></td>
                            <td><?php echo $product['quantity']; ?></td>
                            <td>
                                <?php if ($product['status'] == 'active'): ?>
                                    <span class="status-badge status-active">نشط</span>
                                <?php elseif ($product['status'] == 'sold'): ?>
                                    <span class="status-badge status-completed">مباع</span>
                                <?php else: ?>
                                    <span class="status-badge status-pending">معلق</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $product['views']; ?></td>
                            <td>
                                <div style="display: flex; gap: 5px;">
                                    <a href="../product-details.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-success" 
                                       style="padding: 6px 12px; font-size: 0.85rem;"
                                       target="_blank">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="?toggle_product_status=<?php echo $product['id']; ?>" 
                                       class="btn btn-warning" 
                                       style="padding: 6px 12px; font-size: 0.85rem;"
                                       onclick="return confirm('تغيير الحالة؟')">
                                        <i class="fas fa-sync"></i>
                                    </a>
                                    <a href="?delete_product=<?php echo $product['id']; ?>" 
                                       class="btn btn-danger" 
                                       style="padding: 6px 12px; font-size: 0.85rem;"
                                       onclick="return confirm('حذف المنتج؟')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- ==================== Store Categories View ==================== -->
<div id="store_categories" class="content-section <?php echo $view == 'store_categories' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-tags"></i> تصنيفات المتجر</h3>
        <button class="btn btn-primary" onclick="openCategoryModal()">
            <i class="fas fa-plus"></i> إضافة تصنيف
        </button>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>الأيقونة</th>
                    <th>الاسم</th>
                    <th>الرمز</th>
                    <th>الترتيب</th>
                    <th>الحالة</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($store_categories as $cat): ?>
                    <tr>
                        <td><?php echo $cat['id']; ?></td>
                        <td><i class="fas <?php echo $cat['icon']; ?>" style="font-size: 1.5rem; color: #10b981;"></i></td>
                        <td><strong><?php echo htmlspecialchars($cat['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($cat['slug']); ?></td>
                        <td><?php echo $cat['display_order']; ?></td>
                        <td>
                            <?php if ($cat['is_active']): ?>
                                <span class="status-badge status-active">نشط</span>
                            <?php else: ?>
                                <span class="status-badge status-suspended">معطل</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <button class="btn btn-warning" 
                                        style="padding: 6px 12px; font-size: 0.85rem;"
                                        onclick="editCategory(<?php echo htmlspecialchars(json_encode($cat)); ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="?delete_category=<?php echo $cat['id']; ?>" 
                                   class="btn btn-danger" 
                                   style="padding: 6px 12px; font-size: 0.85rem;"
                                   onclick="return confirm('حذف التصنيف؟')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ==================== Store Orders View ==================== -->
<div id="store_orders" class="content-section <?php echo $view == 'store_orders' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-shopping-cart"></i> طلبات المتجر</h3>
    </div>
    
    <?php if (empty($store_orders)): ?>
        <div style="text-align: center; padding: 60px 20px; background: white; border-radius: 15px;">
            <i class="fas fa-shopping-bag" style="font-size: 4rem; color: #cbd5e1; margin-bottom: 20px;"></i>
            <h3 style="color: #64748b;">لا توجد طلبات</h3>
        </div>
    <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>المنتج</th>
                        <th>المشتري</th>
                        <th>البائع</th>
                        <th>السعر</th>
                        <th>العمولة</th>
                        <th>صافي البائع</th>
                        <th>الحالة</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($store_orders as $order): ?>
                        <tr>
                            <td><?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['product_title']); ?></td>
                            <td><?php echo htmlspecialchars($order['buyer_name']); ?></td>
                            <td><?php echo htmlspecialchars($order['seller_name']); ?></td>
                            <td><strong style="color: #10b981;"><?php echo number_format($order['price'], 2); ?>$</strong></td>
                            <td style="color: #dc2626;"><?php echo number_format($order['commission_amount'], 2); ?>$</td>
                            <td><strong style="color: #059669;"><?php echo number_format($order['seller_net_amount'], 2); ?>$</strong></td>
                            <td>
                                <?php
                                $statuses = [
                                    'pending' => ['معلق', 'status-pending'],
                                    'paid' => ['مدفوع', 'status-active'],
                                    'shipped' => ['تم الشحن', 'status-active'],
                                    'completed' => ['مكتمل', 'status-completed'],
                                    'cancelled' => ['ملغي', 'status-suspended']
                                ];
                                $st = $statuses[$order['status']];
                                ?>
                                <span class="status-badge <?php echo $st[1]; ?>"><?php echo $st[0]; ?></span>
                            </td>
                            <td><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Category Modal -->
<div id="categoryModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="categoryModalTitle"><i class="fas fa-tag"></i> إضافة تصنيف</h3>
            <button class="modal-close" onclick="closeCategoryModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="category_id" id="category_id">
            <div class="form-group">
                <label>اسم التصنيف</label>
                <input type="text" name="name" id="cat_name" required>
            </div>
            <div class="form-group">
                <label>الرمز (slug)</label>
                <input type="text" name="slug" id="cat_slug" required>
            </div>
            <div class="form-group">
                <label>الوصف</label>
                <textarea name="description" id="cat_description" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>أيقونة Font Awesome (مثال: fa-car)</label>
                <input type="text" name="icon" id="cat_icon" placeholder="fa-tag">
            </div>
            <div class="form-group">
                <label>ترتيب العرض</label>
                <input type="number" name="display_order" id="cat_order" value="0">
            </div>
            <button type="submit" name="save_category" class="btn btn-primary">
                <i class="fas fa-save"></i> حفظ
            </button>
        </form>
    </div>
</div>
<!-- ==================== Store Commissions View ==================== -->
<div id="store_commissions" class="content-section <?php echo $view == 'store_commissions' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-percent"></i> عمولات المتجر</h3>
        <button class="btn btn-primary" onclick="openStoreCommissionModal()">
            <i class="fas fa-plus"></i> إضافة شريحة
        </button>
    </div>
    
    <div style="background: #fef3c7; padding: 20px; border-radius: 12px; margin-bottom: 25px; border-right: 4px solid #f59e0b;">
        <h4 style="color: #92400e; margin-bottom: 10px;">
            <i class="fas fa-info-circle"></i> ملاحظة مهمة
        </h4>
        <p style="color: #78350f; margin: 0;">
            هذه العمولات خاصة بمنتجات المتجر فقط. عمولات المزادات لها جدول منفصل.
        </p>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>من السعر</th>
                    <th>إلى السعر</th>
                    <th>نسبة العمولة</th>
                    <th>مثال</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($store_commission_tiers as $tier): ?>
                    <tr>
                        <td><?php echo $tier['id']; ?></td>
                        <td><?php echo number_format($tier['min_price'], 2); ?>$</td>
                        <td><?php echo number_format($tier['max_price'], 2); ?>$</td>
                        <td>
                            <strong style="color: #059669; font-size: 1.1rem;">
                                <?php echo $tier['commission_rate']; ?>%
                            </strong>
                        </td>
                        <td style="color: #64748b; font-size: 0.9rem;">
                            منتج بـ <?php echo number_format(($tier['min_price'] + $tier['max_price']) / 2, 2); ?>$ 
                            = عمولة <?php echo number_format((($tier['min_price'] + $tier['max_price']) / 2) * ($tier['commission_rate'] / 100), 2); ?>$
                        </td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <button class="btn btn-warning" 
                                        style="padding: 6px 12px; font-size: 0.85rem;"
                                        onclick="editStoreCommission(<?php echo htmlspecialchars(json_encode($tier)); ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="?delete_store_tier=<?php echo $tier['id']; ?>" 
                                   class="btn btn-danger" 
                                   style="padding: 6px 12px; font-size: 0.85rem;"
                                   onclick="return confirm('حذف الشريحة؟')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Store Commission Modal -->
<div id="storeCommissionModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="storeCommModalTitle"><i class="fas fa-percent"></i> إضافة شريحة عمولة</h3>
            <button class="modal-close" onclick="closeStoreCommissionModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="tier_id" id="store_tier_id">
            <div class="form-group">
                <label>من السعر ($)</label>
                <input type="number" name="min_price" id="store_min_price" step="0.01" required>
            </div>
            <div class="form-group">
                <label>إلى السعر ($)</label>
                <input type="number" name="max_price" id="store_max_price" step="0.01" required>
            </div>
            <div class="form-group">
                <label>نسبة العمولة (%)</label>
                <input type="number" name="commission_rate" id="store_commission_rate" step="0.01" required>
                <small style="color: #64748b;">مثال: 5.00 تعني 5%</small>
            </div>
            <button type="submit" name="save_store_commission" class="btn btn-primary">
                <i class="fas fa-save"></i> حفظ
            </button>
        </form>
    </div>
</div>
<!-- ==================== Translations Cache View ==================== -->
<div id="translations_cache" class="content-section <?php echo $view == 'translations_cache' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-language"></i> إدارة الترجمات المحفوظة</h3>
        <div>
            <button class="btn btn-primary" onclick="refreshTranslations()">
                <i class="fas fa-sync"></i> تحديث
            </button>
            <button class="btn btn-danger" onclick="clearAllCache()">
                <i class="fas fa-trash"></i> مسح الكل
            </button>
        </div>
    </div>
    
    <?php
    $cache_dir = __DIR__ . '/../cache/translations';
    $languages = [
        'en' => ['name' => 'الإنجليزية', 'flag' => '🇬🇧'],
        'tr' => ['name' => 'التركية', 'flag' => '🇹🇷'],
        'de' => ['name' => 'الألمانية', 'flag' => '🇩🇪']
    ];
    ?>
    
    <div style="display: grid; gap: 25px;">
        <?php foreach ($languages as $code => $lang): ?>
            <?php
            $file = $cache_dir . "/{$code}.json";
            $exists = file_exists($file);
            $cache = $exists ? json_decode(file_get_contents($file), true) : [];
            $count = count($cache);
            $size = $exists ? filesize($file) : 0;
            ?>
            
            <div style="background: white; border-radius: 15px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <span style="font-size: 3rem;"><?php echo $lang['flag']; ?></span>
                        <div>
                            <h3 style="color: #1e293b; margin-bottom: 5px;">
                                <?php echo $lang['name']; ?> (<?php echo $code; ?>)
                            </h3>
                            <p style="color: #64748b; margin: 0;">
                                <?php echo $count; ?> ترجمة محفوظة
                            </p>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <?php if ($exists): ?>
                            <button class="btn btn-warning btn-small" onclick="toggleTranslations('<?php echo $code; ?>')">
                                <i class="fas fa-eye"></i> عرض
                            </button>
                            <a href="../clear-cache.php?lang=<?php echo $code; ?>" 
                               class="btn btn-danger btn-small"
                               onclick="return confirm('مسح ترجمات <?php echo $lang['name']; ?>؟')">
                                <i class="fas fa-trash"></i> مسح
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- إحصائيات -->
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 20px;">
                    <div style="background: #f8fafc; padding: 15px; border-radius: 10px; text-align: center;">
                        <div style="font-size: 1.5rem; font-weight: bold; color: #3b82f6;">
                            <?php echo $count; ?>
                        </div>
                        <div style="font-size: 0.85rem; color: #64748b;">عدد الترجمات</div>
                    </div>
                    
                    <div style="background: #f8fafc; padding: 15px; border-radius: 10px; text-align: center;">
                        <div style="font-size: 1.5rem; font-weight: bold; color: #10b981;">
                            <?php echo round($size / 1024, 2); ?> KB
                        </div>
                        <div style="font-size: 0.85rem; color: #64748b;">حجم الملف</div>
                    </div>
                    
                    <div style="background: #f8fafc; padding: 15px; border-radius: 10px; text-align: center;">
                        <div style="font-size: 1.5rem; font-weight: bold; color: <?php echo $exists ? '#10b981' : '#ef4444'; ?>;">
                            <i class="fas fa-<?php echo $exists ? 'check-circle' : 'times-circle'; ?>"></i>
                        </div>
                        <div style="font-size: 0.85rem; color: #64748b;">
                            <?php echo $exists ? 'متوفر' : 'غير متوفر'; ?>
                        </div>
                    </div>
                </div>
                
<!-- جدول الترجمات -->
<?php if ($exists && $count > 0): ?>
    <div id="translations_<?php echo $code; ?>" style="display: none; margin-top: 20px;">
        <div style="background: #f8fafc; border-radius: 10px; padding: 15px; max-height: 500px; overflow-y: auto;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 2px solid #e2e8f0;">
                        <th style="padding: 10px; text-align: right; color: #64748b; font-size: 0.9rem; width: 50px;">#</th>
                        <th style="padding: 10px; text-align: right; color: #64748b; font-size: 0.9rem;">النص العربي</th>
                        <th style="padding: 10px; text-align: right; color: #64748b; font-size: 0.9rem;">الترجمة</th>
                        <th style="padding: 10px; text-align: center; color: #64748b; font-size: 0.9rem; width: 150px;">إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $index = 1;
                    foreach ($cache as $ar => $trans): 
                    ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 10px; color: #94a3b8;"><?php echo $index++; ?></td>
                            
                            <td style="padding: 10px; color: #1e293b; font-weight: 500;">
                                <?php echo htmlspecialchars($ar); ?>
                            </td>
                            
                            <td style="padding: 10px;">
                                <div id="view_<?php echo $code; ?>_<?php echo md5($ar); ?>">
                                    <span style="color: #64748b;">
                                        <?php echo htmlspecialchars($trans); ?>
                                    </span>
                                </div>
                                <div id="edit_<?php echo $code; ?>_<?php echo md5($ar); ?>" style="display: none;">
                                    <input type="text" 
                                           value="<?php echo htmlspecialchars($trans); ?>" 
                                           style="width: 100%; padding: 8px 12px; border: 2px solid #3b82f6; border-radius: 8px; font-size: 0.95rem;"
                                           id="input_<?php echo $code; ?>_<?php echo md5($ar); ?>">
                                </div>
                            </td>
                            
                            <td style="padding: 10px; text-align: center;">
                                <div id="actions_<?php echo $code; ?>_<?php echo md5($ar); ?>">
                                    <div class="normal-actions">
                                        <button class="btn btn-warning" 
                                                style="padding: 6px 12px; font-size: 0.8rem; margin: 0 2px;"
                                                onclick="editTranslation('<?php echo $code; ?>', '<?php echo md5($ar); ?>', '<?php echo addslashes($ar); ?>')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-danger" 
                                                style="padding: 6px 12px; font-size: 0.8rem; margin: 0 2px;"
                                                onclick="deleteTranslation('<?php echo $code; ?>', '<?php echo addslashes($ar); ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                    
                                    <div class="edit-actions" style="display: none;">
                                        <button class="btn btn-success" 
                                                style="padding: 6px 12px; font-size: 0.8rem; margin: 0 2px;"
                                                onclick="saveTranslation('<?php echo $code; ?>', '<?php echo md5($ar); ?>', '<?php echo addslashes($ar); ?>')">
                                            <i class="fas fa-check"></i> حفظ
                                        </button>
                                        <button class="btn" 
                                                style="padding: 6px 12px; font-size: 0.8rem; margin: 0 2px; background: #64748b; color: white;"
                                                onclick="cancelEdit('<?php echo $code; ?>', '<?php echo md5($ar); ?>')">
                                            <i class="fas fa-times"></i> إلغاء
                                        </button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <div style="text-align: center; padding: 30px; color: #94a3b8;">
        <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.5;"></i>
        <p>لا توجد ترجمات محفوظة بعد</p>
    </div>
<?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- ملاحظات -->
    <div style="background: #dbeafe; border: 2px solid #3b82f6; border-radius: 15px; padding: 20px; margin-top: 25px;">
        <h4 style="color: #1e40af; margin-bottom: 10px;">
            <i class="fas fa-info-circle"></i> ملاحظات مهمة:
        </h4>
        <ul style="color: #1e40af; line-height: 1.8; padding-right: 20px; margin: 0;">
            <li>الترجمات تُحفظ تلقائياً عند استخدام الموقع</li>
            <li>مسح الكاش سيجبر النظام على إعادة الترجمة من API</li>
            <li>الملفات محفوظة في: <code style="background: white; padding: 2px 8px; border-radius: 4px;">cache/translations/</code></li>
            <li>كلما زاد عدد الترجمات، كلما أصبح الموقع أسرع</li>
        </ul>
    </div>
</div>
<!-- نهاية Translations Cache View -->

<!-- Modal إضافة ترجمة -->
<div id="addTranslationModal" class="modal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h3><i class="fas fa-plus-circle"></i> إضافة ترجمة جديدة</h3>
            <button class="modal-close" onclick="closeAddTranslationModal()">&times;</button>
        </div>
        <form onsubmit="saveNewTranslation(event)">
            <input type="hidden" id="new_trans_lang">
            
            <div class="form-group">
                <label>النص العربي</label>
                <textarea id="new_trans_arabic" rows="3" required 
                          style="width: 100%; padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; font-size: 1rem;"></textarea>
            </div>
            
            <div class="form-group">
                <label>الترجمة</label>
                <textarea id="new_trans_translation" rows="3" required 
                          style="width: 100%; padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; font-size: 1rem;"></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> حفظ الترجمة
            </button>
        </form>
    </div>
</div>
<!-- ==================== Subscription Plans View ==================== -->
<div id="subscription_plans" class="content-section <?php echo $view == 'subscription_plans' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-crown"></i> إدارة خطط الاشتراكات</h3>
        <button class="btn btn-primary" onclick="openPlanModal()">
            <i class="fas fa-plus"></i> إضافة خطة
        </button>
    </div>
    
    <div style="display: grid; gap: 25px;">
        <?php foreach ($subscription_plans as $plan): ?>
            <?php $features = getPlanFeatures($plan['id']); ?>
            
            <div style="background: white; border-radius: 15px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border-right: 5px solid <?php echo $plan['color']; ?>;">
                <div style="display: grid; grid-template-columns: auto 1fr auto; gap: 25px; align-items: start;">
                    <!-- أيقونة الخطة -->
                    <div style="width: 80px; height: 80px; border-radius: 50%; background: <?php echo $plan['color']; ?>; color: white; display: flex; align-items: center; justify-content: center; font-size: 2rem;">
                        <i class="fas <?php echo $plan['icon']; ?>"></i>
                    </div>
                    
                    <!-- معلومات الخطة -->
                    <div>
                        <h3 style="color: #1e293b; margin-bottom: 10px; font-size: 1.5rem;">
                            <?php echo $plan['name']; ?>
                        </h3>
                        <p style="color: #64748b; margin-bottom: 15px;">
                            <?php echo $plan['description']; ?>
                        </p>
                        
                        <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                            <div>
                                <strong style="color: #1e293b;">الاشتراك الشهري:</strong>
                                <span style="font-size: 1.5rem; color: <?php echo $plan['color']; ?>; font-weight: bold;">
                                    $<?php echo number_format($plan['price_monthly'], 2); ?>
                                </span>
                            </div>
                            <div>
                                <strong style="color: #1e293b;">الاشتراك السنوي:</strong>
                                <span style="font-size: 1.5rem; color: <?php echo $plan['color']; ?>; font-weight: bold;">
                                    $<?php echo number_format($plan['price_yearly'], 2); ?>
                                </span>
                            </div>
                        </div>
                        
                        <!-- الميزات -->
                        <div style="background: #f8fafc; padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                            <h4 style="color: #1e293b; margin-bottom: 10px; font-size: 1rem;">
                                <i class="fas fa-list"></i> الميزات:
                            </h4>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px;">
                                <?php foreach ($features as $feature): ?>
                                    <div style="display: flex; align-items: center; gap: 8px; padding: 8px; background: white; border-radius: 8px;">
                                        <i class="fas fa-check-circle" style="color: #10b981;"></i>
                                        <span style="font-size: 0.9rem; color: #475569;">
                                            <?php echo $feature['feature_name']; ?>: 
                                            <strong><?php echo $feature['feature_value']; ?></strong>
                                        </span>
                                        <button class="btn btn-danger" 
                                                style="padding: 4px 8px; font-size: 0.7rem; margin-right: auto;"
                                                onclick="if(confirm('حذف الميزة؟')) window.location.href='?delete_feature=<?php echo $feature['id']; ?>'">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <button class="btn btn-success btn-small" 
                                    style="margin-top: 10px;"
                                    onclick="openFeatureModal(<?php echo $plan['id']; ?>)">
                                <i class="fas fa-plus"></i> إضافة ميزة
                            </button>
                        </div>
                    </div>
                    
                    <!-- إجراءات -->
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <button class="btn btn-warning btn-small" 
                                onclick="editPlan(<?php echo htmlspecialchars(json_encode($plan)); ?>)">
                            <i class="fas fa-edit"></i> تعديل
                        </button>
                        
                        <?php if ($plan['id'] != 1): // لا يمكن حذف الخطة المجانية ?>
                            <a href="?delete_plan=<?php echo $plan['id']; ?>" 
                               class="btn btn-danger btn-small"
                               onclick="return confirm('حذف الخطة؟')">
                                <i class="fas fa-trash"></i> حذف
                            </a>
                        <?php endif; ?>
                        
                        <div style="background: #f8fafc; padding: 10px; border-radius: 8px; text-align: center;">
                            <div style="font-size: 1.5rem; font-weight: bold; color: <?php echo $plan['color']; ?>;">
                                <?php
                                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM user_subscriptions WHERE plan_id = ? AND status = 'active'");
                                $stmt->execute([$plan['id']]);
                                echo $stmt->fetch()['count'];
                                ?>
                            </div>
                            <div style="font-size: 0.8rem; color: #64748b;">مشترك نشط</div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Plan Modal -->
<div id="planModal" class="modal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h3 id="planModalTitle"><i class="fas fa-crown"></i> إضافة خطة</h3>
            <button class="modal-close" onclick="closePlanModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="plan_id" id="plan_id">
            
            <div class="form-group">
                <label>اسم الخطة</label>
                <input type="text" name="name" id="plan_name" required>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>السعر الشهري ($)</label>
                    <input type="number" name="price_monthly" id="plan_price_monthly" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label>السعر السنوي ($)</label>
                    <input type="number" name="price_yearly" id="plan_price_yearly" step="0.01" required>
                </div>
            </div>
            
            <div class="form-group">
                <label>الوصف</label>
                <textarea name="description" id="plan_description" rows="3"></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>الأيقونة (Font Awesome)</label>
                    <input type="text" name="icon" id="plan_icon" placeholder="fa-crown" required>
                </div>
                
                <div class="form-group">
                    <label>اللون</label>
                    <input type="color" name="color" id="plan_color" required>
                </div>
                
                <div class="form-group">
                    <label>الترتيب</label>
                    <input type="number" name="display_order" id="plan_order" value="0" required>
                </div>
            </div>
            
            <button type="submit" name="save_plan" class="btn btn-primary">
                <i class="fas fa-save"></i> حفظ
            </button>
        </form>
    </div>
</div>

<!-- Feature Modal -->
<div id="featureModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="featureModalTitle"><i class="fas fa-star"></i> إضافة ميزة</h3>
            <button class="modal-close" onclick="closeFeatureModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="feature_id" id="feature_id">
            <input type="hidden" name="plan_id" id="feature_plan_id">
            
            <div class="form-group">
                <label>مفتاح الميزة (Key)</label>
                <input type="text" name="feature_key" id="feature_key" placeholder="max_auctions" required>
                <small style="color: #64748b;">يُستخدم في البرمجة للتحقق</small>
            </div>
            
            <div class="form-group">
                <label>اسم الميزة</label>
                <input type="text" name="feature_name" id="feature_name" placeholder="عدد المزادات" required>
            </div>
            
            <div class="form-group">
                <label>قيمة الميزة</label>
                <input type="text" name="feature_value" id="feature_value" placeholder="10" required>
                <small style="color: #64748b;">أمثلة: 10، غير محدود، نعم، 5%</small>
            </div>
            
            <div class="form-group">
                <label>الترتيب</label>
                <input type="number" name="display_order" id="feature_order" value="0" required>
            </div>
            
            <button type="submit" name="save_feature" class="btn btn-primary">
                <i class="fas fa-save"></i> حفظ
            </button>
        </form>
    </div>
</div>

<!-- ==================== Subscription Users View ==================== -->
<div id="subscription_users" class="content-section <?php echo $view == 'subscription_users' ? 'active' : ''; ?>">
    <div class="section-header">
        <h3><i class="fas fa-users-cog"></i> اشتراكات المستخدمين</h3>
        <div style="color: #64748b;">
            إجمالي الاشتراكات النشطة: <strong><?php echo $stats['active_subscriptions']; ?></strong>
        </div>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>المستخدم</th>
                    <th>الخطة</th>
                    <th>المبلغ المدفوع</th>
                    <th>تاريخ البداية</th>
                    <th>تاريخ الانتهاء</th>
                    <th>الحالة</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($user_subscriptions as $sub): ?>
                    <tr>
                        <td><?php echo $sub['id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($sub['username']); ?></strong></td>
                        <td>
                            <span style="background: <?php echo $sub['color']; ?>20; color: <?php echo $sub['color']; ?>; padding: 6px 12px; border-radius: 20px; font-weight: 600;">
                                <?php echo $sub['plan_name']; ?>
                            </span>
                        </td>
                        <td><strong style="color: #10b981;">$<?php echo number_format($sub['amount_paid'], 2); ?></strong></td>
                        <td><?php echo date('Y-m-d', strtotime($sub['starts_at'])); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($sub['expires_at'])); ?></td>
                        <td>
                            <?php if ($sub['status'] == 'active'): ?>
                                <span class="status-badge status-active">نشط</span>
                            <?php elseif ($sub['status'] == 'expired'): ?>
                                <span class="status-badge status-expired">منتهي</span>
                            <?php else: ?>
                                <span class="status-badge status-cancelled">ملغي</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($sub['status'] == 'active'): ?>
                                <a href="?cancel_subscription=<?php echo $sub['id']; ?>" 
                                   class="btn btn-danger btn-small"
                                   onclick="return confirm('إلغاء الاشتراك؟')">
                                    <i class="fas fa-times"></i> إلغاء
                                </a>
                            <?php else: ?>
                                <span style="color: #94a3b8;">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</main>

<!-- Balance Modal -->
<div id="balanceModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-wallet"></i> تعديل الرصيد</h3>
            <button class="modal-close" onclick="closeBalanceModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="user_id" id="modal_user_id">
            <div class="form-group">
                <label>المستخدم</label>
                <input type="text" id="modal_username" disabled style="background: #f1f5f9;">
            </div>
            <div class="form-group">
                <label>المبلغ ($)</label>
                <input type="number" name="amount" step="0.01" required>
            </div>
            <div class="form-group">
                <label>العملية</label>
                <select name="action" required>
                    <option value="add">إضافة رصيد</option>
                    <option value="deduct">خصم رصيد</option>
                </select>
            </div>
            <button type="submit" name="update_balance" class="btn btn-primary">
                <i class="fas fa-check"></i> تنفيذ
            </button>
        </form>
    </div>
</div>

<script>
    // View Switching
    function showView(viewName) {
        document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
        document.getElementById(viewName).classList.add('active');
        event.target.closest('.menu-item').classList.add('active');
        
        const url = new URL(window.location);
        url.searchParams.set('view', viewName);
        window.history.pushState({}, '', url);
    }

    function filterTable(tableId, searchId) {
        const input = document.getElementById(searchId);
        const filter = input.value.toUpperCase();
        const table = document.getElementById(tableId);
        const tr = table.getElementsByTagName('tr');
        
        for (let i = 1; i < tr.length; i++) {
            let td = tr[i].getElementsByTagName('td');
            let found = false;
            for (let j = 0; j < td.length; j++) {
                if (td[j]) {
                    if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                        break;
                    }
                }
            }
            tr[i].style.display = found ? '' : 'none';
        }
    }

    function openBalanceModal(userId, username) {
        document.getElementById('modal_user_id').value = userId;
        document.getElementById('modal_username').value = username;
        document.getElementById('balanceModal').classList.add('active');
    }

    function closeBalanceModal() {
        document.getElementById('balanceModal').classList.remove('active');
    }

    // Charts
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($monthly_data, 'month')); ?>,
            datasets: [{
                label: 'الإيرادات ($)',
                data: <?php echo json_encode(array_column($monthly_data, 'revenue')); ?>,
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                tension: 0.4,
                fill: true,
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + '$';
                        }
                    }
                }
            }
        }
    });

    const auctionsCtx = document.getElementById('auctionsChart').getContext('2d');
    new Chart(auctionsCtx, {
        type: 'doughnut',
        data: {
            labels: ['نشطة', 'مكتملة', 'ملغية'],
            datasets: [{
                data: [
                    <?php echo $stats['active_auctions']; ?>, 
                    <?php echo $stats['completed_auctions']; ?>,
                    <?php echo $stats['cancelled_auctions']; ?>
                ],
                backgroundColor: ['#10b981', '#3b82f6', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        font: { size: 13 }
                    }
                }
            }
        }
    });

    const revenueBreakdownCtx = document.getElementById('revenueBreakdownChart').getContext('2d');
    new Chart(revenueBreakdownCtx, {
        type: 'bar',
        data: {
            labels: ['إجمالي المبيعات', 'العمولات المكتسبة', 'مبيعات البائعين'],
            datasets: [{
                data: [
                    <?php echo $stats['total_revenue']; ?>,
                    <?php echo $stats['commission_earned']; ?>,
                    <?php echo $stats['total_revenue'] - $stats['commission_earned']; ?>
                ],
                backgroundColor: ['#3b82f6', '#f59e0b', '#10b981'],
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + '$';
                        }
                    }
                }
            }
        }
    });

    const usersGrowthCtx = document.getElementById('usersGrowthChart').getContext('2d');
    new Chart(usersGrowthCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($monthly_data, 'month')); ?>,
            datasets: [{
                label: 'المستخدمين الجدد',
                data: [5, 8, 12, 15, 18, 22, 28, 35, 42, 50, 58, <?php echo $stats['new_users_month']; ?>],
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
                fill: true,
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // Modals
    let currentAuctionData = null;
    let currentReactivateAuctionId = null;
    let currentRejectKycId = null;

    function openEditAuctionModal(auction) {
        currentAuctionData = auction;
        document.getElementById('edit_auction_id').value = auction.id;
        document.getElementById('edit_auction_vehicle').value = auction.brand + ' ' + auction.model + ' ' + auction.year;
        document.getElementById('edit_starting_price').value = auction.starting_price;
        document.getElementById('edit_min_bid_increment').value = auction.min_bid_increment || 50;
        
        const endTime = new Date(auction.end_time);
        const formattedTime = endTime.toISOString().slice(0, 16);
        document.getElementById('edit_end_time').value = formattedTime;
        
        document.getElementById('editAuctionModal').classList.add('active');
    }

    function closeEditAuctionModal() {
        document.getElementById('editAuctionModal').classList.remove('active');
    }

    function openReactivateModal(auctionId) {
        currentReactivateAuctionId = auctionId;
        document.getElementById('reactivateModal').classList.add('active');
    }

    function closeReactivateModal() {
        document.getElementById('reactivateModal').classList.remove('active');
    }

    function reactivateAuction(hours) {
        if (!hours || hours <= 0) {
            alert('يرجى إدخال عدد ساعات صحيح');
            return;
        }
        
        if (confirm(`إعادة تفعيل المزاد لمدة ${hours} ساعة؟`)) {
            window.location.href = `?reactivate_auction=${currentReactivateAuctionId}&hours=${hours}`;
        }
    }

    function openRejectModal(kycId) {
        currentRejectKycId = kycId;
        document.getElementById('rejectKycModal').classList.add('active');
    }

    function closeRejectKycModal() {
        document.getElementById('rejectKycModal').classList.remove('active');
    }

    function submitRejection() {
        const reason = document.getElementById('rejection_reason').value;
        if (!reason || reason.trim() === '') {
            alert('يرجى إدخال سبب الرفض');
            return;
        }
        window.location.href = `?reject_kyc=${currentRejectKycId}&reason=${encodeURIComponent(reason)}`;
    }

    function openCategoryModal() {
        document.getElementById('categoryModal').classList.add('active');
        document.getElementById('categoryModalTitle').innerHTML = '<i class="fas fa-tag"></i> إضافة تصنيف';
        document.getElementById('category_id').value = '';
        document.getElementById('cat_name').value = '';
        document.getElementById('cat_slug').value = '';
        document.getElementById('cat_description').value = '';
        document.getElementById('cat_icon').value = '';
        document.getElementById('cat_order').value = '0';
    }

    function closeCategoryModal() {
        document.getElementById('categoryModal').classList.remove('active');
    }

    function editCategory(cat) {
        document.getElementById('categoryModal').classList.add('active');
        document.getElementById('categoryModalTitle').innerHTML = '<i class="fas fa-edit"></i> تعديل تصنيف';
        document.getElementById('category_id').value = cat.id;
        document.getElementById('cat_name').value = cat.name;
        document.getElementById('cat_slug').value = cat.slug;
        document.getElementById('cat_description').value = cat.description || '';
        document.getElementById('cat_icon').value = cat.icon;
        document.getElementById('cat_order').value = cat.display_order;
    }

    function openStoreCommissionModal() {
        document.getElementById('storeCommissionModal').classList.add('active');
        document.getElementById('storeCommModalTitle').innerHTML = '<i class="fas fa-percent"></i> إضافة شريحة عمولة';
        document.getElementById('store_tier_id').value = '';
        document.getElementById('store_min_price').value = '';
        document.getElementById('store_max_price').value = '';
        document.getElementById('store_commission_rate').value = '';
    }

    function closeStoreCommissionModal() {
        document.getElementById('storeCommissionModal').classList.remove('active');
    }

    function editStoreCommission(tier) {
        document.getElementById('storeCommissionModal').classList.add('active');
        document.getElementById('storeCommModalTitle').innerHTML = '<i class="fas fa-edit"></i> تعديل شريحة عمولة';
        document.getElementById('store_tier_id').value = tier.id;
        document.getElementById('store_min_price').value = tier.min_price;
        document.getElementById('store_max_price').value = tier.max_price;
        document.getElementById('store_commission_rate').value = tier.commission_rate;
    }

    // Translations functions
    function toggleTranslations(lang) {
        const el = document.getElementById('translations_' + lang);
        if (el.style.display === 'none') {
            el.style.display = 'block';
        } else {
            el.style.display = 'none';
        }
    }

    function editTranslation(lang, hash, originalText) {
        document.getElementById('view_' + lang + '_' + hash).style.display = 'none';
        document.getElementById('edit_' + lang + '_' + hash).style.display = 'block';
        
        const actions = document.querySelector('#actions_' + lang + '_' + hash);
        actions.querySelector('.normal-actions').style.display = 'none';
        actions.querySelector('.edit-actions').style.display = 'block';
        
        document.getElementById('input_' + lang + '_' + hash).focus();
    }

    function cancelEdit(lang, hash) {
        document.getElementById('view_' + lang + '_' + hash).style.display = 'block';
        document.getElementById('edit_' + lang + '_' + hash).style.display = 'none';
        
        const actions = document.querySelector('#actions_' + lang + '_' + hash);
        actions.querySelector('.normal-actions').style.display = 'block';
        actions.querySelector('.edit-actions').style.display = 'none';
    }

    function saveTranslation(lang, hash, originalText) {
        const newTranslation = document.getElementById('input_' + lang + '_' + hash).value.trim();
        
        if (!newTranslation) {
            alert('الترجمة لا يمكن أن تكون فارغة!');
            return;
        }
        
        const btn = event.target;
        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';
        btn.disabled = true;
        
        fetch('../update-translation.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                lang: lang,
                original_text: originalText,
                new_translation: newTranslation
            })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                document.querySelector('#view_' + lang + '_' + hash + ' span').textContent = newTranslation;
                cancelEdit(lang, hash);
                showNotification('تم تحديث الترجمة بنجاح!', 'success');
            } else {
                alert('فشل التحديث: ' + data.error);
            }
            
            btn.innerHTML = originalHTML;
            btn.disabled = false;
        })
        .catch(err => {
            alert('حدث خطأ: ' + err.message);
            btn.innerHTML = originalHTML;
            btn.disabled = false;
        });
    }

    function deleteTranslation(lang, text) {
        if (confirm('حذف هذه الترجمة؟\n\n' + text)) {
            fetch('../delete-translation.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({lang: lang, text: text})
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showNotification('تم الحذف بنجاح!', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    alert('فشل الحذف: ' + data.error);
                }
            });
        }
    }

    function clearAllCache() {
        if (confirm('هل أنت متأكد من مسح جميع الترجمات؟')) {
            window.location.href = '../clear-cache.php?lang=all&redirect=admin';
        }
    }

    function refreshTranslations() {
        location.reload();
    }

    function openAddTranslationModal(lang) {
        document.getElementById('new_trans_lang').value = lang;
        document.getElementById('addTranslationModal').classList.add('active');
    }

    function closeAddTranslationModal() {
        document.getElementById('addTranslationModal').classList.remove('active');
        document.getElementById('new_trans_arabic').value = '';
        document.getElementById('new_trans_translation').value = '';
    }

    function saveNewTranslation(event) {
        event.preventDefault();
        
        const lang = document.getElementById('new_trans_lang').value;
        const arabic = document.getElementById('new_trans_arabic').value.trim();
        const translation = document.getElementById('new_trans_translation').value.trim();
        
        fetch('../update-translation.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                lang: lang,
                original_text: arabic,
                new_translation: translation
            })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showNotification('تمت الإضافة بنجاح!', 'success');
                closeAddTranslationModal();
                setTimeout(() => location.reload(), 1000);
            } else {
                alert('فشلت الإضافة: ' + data.error);
            }
        });
    }

    function showNotification(message, type) {
        const notif = document.createElement('div');
        notif.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: ${type === 'success' ? '#10b981' : '#ef4444'};
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            z-index: 99999;
            font-weight: 600;
        `;
        notif.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;
        
        document.body.appendChild(notif);
        
        setTimeout(() => notif.remove(), 3000);
    }

    window.onclick = function(event) {
        if (event.target.className === 'modal active') {
            event.target.classList.remove('active');
        }
    }
    // Plan Modal
function openPlanModal() {
    document.getElementById('planModal').classList.add('active');
    document.getElementById('planModalTitle').innerHTML = '<i class="fas fa-crown"></i> إضافة خطة';
    document.getElementById('plan_id').value = '';
    document.getElementById('plan_name').value = '';
    document.getElementById('plan_price_monthly').value = '';
    document.getElementById('plan_price_yearly').value = '';
    document.getElementById('plan_description').value = '';
    document.getElementById('plan_icon').value = 'fa-star';
    document.getElementById('plan_color').value = '#3b82f6';
    document.getElementById('plan_order').value = '0';
}

function closePlanModal() {
    document.getElementById('planModal').classList.remove('active');
}

function editPlan(plan) {
    document.getElementById('planModal').classList.add('active');
    document.getElementById('planModalTitle').innerHTML = '<i class="fas fa-edit"></i> تعديل خطة';
    document.getElementById('plan_id').value = plan.id;
    document.getElementById('plan_name').value = plan.name;
    document.getElementById('plan_price_monthly').value = plan.price_monthly;
    document.getElementById('plan_price_yearly').value = plan.price_yearly;
    document.getElementById('plan_description').value = plan.description || '';
    document.getElementById('plan_icon').value = plan.icon;
    document.getElementById('plan_color').value = plan.color;
    document.getElementById('plan_order').value = plan.display_order;
}

// Feature Modal
function openFeatureModal(planId) {
    document.getElementById('featureModal').classList.add('active');
    document.getElementById('featureModalTitle').innerHTML = '<i class="fas fa-star"></i> إضافة ميزة';
    document.getElementById('feature_id').value = '';
    document.getElementById('feature_plan_id').value = planId;
    document.getElementById('feature_key').value = '';
    document.getElementById('feature_name').value = '';
    document.getElementById('feature_value').value = '';
    document.getElementById('feature_order').value = '0';
}

function closeFeatureModal() {
    document.getElementById('featureModal').classList.remove('active');
}
</script>
</body>
</html>