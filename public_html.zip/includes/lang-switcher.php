<?php
$current_lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : 'ar';

$languages = [
    'ar' => ['name' => 'العربية', 'flag' => '🇸🇦', 'dir' => 'rtl'],
    'en' => ['name' => 'English', 'flag' => '🇬🇧', 'dir' => 'ltr'],
    'tr' => ['name' => 'Türkçe', 'flag' => '🇹🇷', 'dir' => 'ltr'],
    'de' => ['name' => 'Deutsch', 'flag' => '🇩🇪', 'dir' => 'ltr']
];
?>

<div class="lang-switcher-container">
    <button class="lang-button" id="langButton">
        <span class="flag-icon"><?php echo $languages[$current_lang]['flag']; ?></span>
        <span class="lang-name"><?php echo $languages[$current_lang]['name']; ?></span>
        <i class="fas fa-chevron-down arrow-icon"></i>
    </button>
    
    <div class="lang-dropdown" id="langDropdown">
        <?php foreach ($languages as $code => $lang): ?>
            <?php if ($code !== $current_lang): ?>
                <a href="#" class="lang-option" data-lang="<?php echo $code; ?>" data-dir="<?php echo $lang['dir']; ?>">
                    <span class="flag-icon"><?php echo $lang['flag']; ?></span>
                    <span class="lang-text"><?php echo $lang['name']; ?></span>
                </a>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>

<style>
.lang-switcher-container {
    position: relative;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.lang-button {
    display: flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 50px;
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    transition: all 0.3s ease;
    min-width: 160px;
    justify-content: space-between;
}

.lang-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
    background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
}

.lang-button:active {
    transform: translateY(0);
}

.flag-icon {
    font-size: 1.8rem;
    line-height: 1;
    filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
}

.lang-name {
    flex: 1;
    text-align: left;
    font-weight: 600;
    letter-spacing: 0.5px;
}

.arrow-icon {
    font-size: 0.8rem;
    transition: transform 0.3s ease;
}

.lang-button.active .arrow-icon {
    transform: rotate(180deg);
}

.lang-dropdown {
    position: absolute;
    top: calc(100% + 10px);
    left: 0;
    right: 0;
    background: white;
    border-radius: 15px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    opacity: 0;
    visibility: hidden;
    transform: translateY(-10px);
    transition: all 0.3s ease;
    overflow: hidden;
    z-index: 1000;
}

.lang-dropdown.active {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.lang-option {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 20px;
    color: #333;
    text-decoration: none;
    transition: all 0.3s ease;
    border-bottom: 1px solid #f0f0f0;
}

.lang-option:last-child {
    border-bottom: none;
}

.lang-option:hover {
    background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
    padding-right: 25px;
}

.lang-option .flag-icon {
    font-size: 1.6rem;
}

.lang-text {
    font-weight: 500;
    font-size: 0.95rem;
}

/* Animation for flag change */
@keyframes flagPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.2); }
}

.lang-button .flag-icon {
    animation: flagPulse 2s infinite;
}

/* Responsive */
@media (max-width: 768px) {
    .lang-button {
        min-width: 140px;
        padding: 10px 16px;
        font-size: 0.9rem;
    }
    
    .flag-icon {
        font-size: 1.5rem;
    }
    
    .lang-name {
        font-size: 0.9rem;
    }
}

/* تأثير عند التحويل */
.lang-switching {
    pointer-events: none;
    opacity: 0.7;
}

.lang-switching::after {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const langButton = document.getElementById('langButton');
    const langDropdown = document.getElementById('langDropdown');
    const langOptions = document.querySelectorAll('.lang-option');

    // Toggle dropdown
    langButton.addEventListener('click', function(e) {
        e.stopPropagation();
        langButton.classList.toggle('active');
        langDropdown.classList.toggle('active');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.lang-switcher-container')) {
            langButton.classList.remove('active');
            langDropdown.classList.remove('active');
        }
    });

    // Handle language selection
    langOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            
            const selectedLang = this.dataset.lang;
            const selectedDir = this.dataset.dir;
            
            // Add loading state
            document.body.classList.add('lang-switching');
            
            // Set cookie
            document.cookie = `lang=${selectedLang}; path=/; max-age=31536000`;
            
            // Change direction
            document.documentElement.setAttribute('lang', selectedLang);
            document.documentElement.setAttribute('dir', selectedDir);
            document.body.setAttribute('dir', selectedDir);
            
            // Reload page after short delay
            setTimeout(() => {
                window.location.reload();
            }, 300);
        });
    });

    // Close dropdown on ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            langButton.classList.remove('active');
            langDropdown.classList.remove('active');
        }
    });
});
</script>