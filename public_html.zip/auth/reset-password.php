<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';
require_once '../includes/functions.php';

// معالجة POST فقط
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    
    try {
        $token = isset($_GET['token']) ? trim($_GET['token']) : '';
        
        if (empty($token)) {
            throw new Exception('الرابط غير صحيح');
        }
        
        // التحقق من التوكن
        $check = $conn->prepare("
            SELECT pr.id, pr.user_id, pr.expires_at, u.email, u.username
            FROM password_resets pr
            JOIN users u ON pr.user_id = u.id
            WHERE pr.token = ? AND pr.used_at IS NULL
            LIMIT 1
        ");
        $check->execute([$token]);
        $reset = $check->fetch(PDO::FETCH_ASSOC);
        
        if (!$reset) {
            throw new Exception('الرابط غير صحيح أو انتهت صلاحيته');
        }
        
        // التحقق من انتهاء الصلاحية
        $expiry = new DateTime($reset['expires_at']);
        $now = new DateTime();
        if ($now > $expiry) {
            throw new Exception('انتهت صلاحية الرابط');
        }
        
        // التحقق من البيانات
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
        
        if (empty($password) || strlen($password) < 6) {
            throw new Exception('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
        }
        
        if ($password !== $confirm) {
            throw new Exception('كلمات المرور غير متطابقة');
        }
        
        // تحديث كلمة المرور
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        
        $update = $conn->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
        $update->execute([$hashed, $reset['user_id']]);
        
        // تحديث التوكن
        $mark = $conn->prepare("UPDATE password_resets SET used_at = NOW() WHERE token = ?");
        $mark->execute([$token]);
        
        echo json_encode([
            'success' => true,
            'message' => 'تم تحديث كلمة المرور بنجاح!',
            'redirect' => 'login.php'
        ]);
        exit;
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'errors' => [$e->getMessage()]
        ]);
        exit;
    }
}

// معالجة GET - عرض الصفحة
if (!isset($_GET['token'])) {
    header('Location: ../index.php');
    exit;
}

$token = trim($_GET['token']);
$valid = false;
$error = '';

try {
    $stmt = $conn->prepare("
        SELECT pr.expires_at FROM password_resets pr
        WHERE pr.token = ? AND pr.used_at IS NULL
        LIMIT 1
    ");
    $stmt->execute([$token]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        $expiry = new DateTime($result['expires_at']);
        $now = new DateTime();
        if ($now <= $expiry) {
            $valid = true;
        } else {
            $error = 'انتهت صلاحية الرابط';
        }
    } else {
        $error = 'رابط غير صحيح';
    }
} catch (Exception $e) {
    $error = 'حدث خطأ';
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعيين كلمة المرور الجديدة</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Cairo', sans-serif; background: #0f172a; min-height: 100vh; display: grid; place-items: center; padding: 20px; direction: rtl; }
        .container { width: 100%; max-width: 450px; }
        .card { background: rgba(30, 41, 59, 0.9); border: 1px solid rgba(148, 163, 184, 0.1); border-radius: 24px; padding: 40px; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5); }
        .brand { text-align: center; margin-bottom: 40px; }
        .brand-icon { width: 70px; height: 70px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); border-radius: 16px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 20px; box-shadow: 0 8px 24px rgba(99, 102, 241, 0.4); }
        .brand-icon i { font-size: 2rem; color: white; }
        .brand h1 { font-size: 1.6rem; color: #f1f5f9; margin-bottom: 10px; font-weight: 700; }
        .brand p { color: #94a3b8; font-size: 0.9rem; }
        .form-group { margin-bottom: 24px; }
        .form-label { display: block; color: #cbd5e1; font-weight: 600; margin-bottom: 10px; font-size: 0.9rem; }
        .input-group { position: relative; }
        .input-group i { position: absolute; right: 16px; top: 50%; transform: translateY(-50%); color: #64748b; transition: color 0.3s; }
        .form-control { width: 100%; padding: 14px 48px 14px 16px; background: rgba(15, 23, 42, 0.5); border: 2px solid rgba(148, 163, 184, 0.2); border-radius: 12px; color: #f1f5f9; font-family: 'Cairo', sans-serif; transition: all 0.3s; }
        .form-control:focus { outline: none; border-color: #6366f1; background: rgba(15, 23, 42, 0.8); }
        .form-control:focus + i { color: #6366f1; }
        .btn { width: 100%; padding: 16px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); border: none; border-radius: 12px; color: white; font-weight: 600; font-family: 'Cairo', sans-serif; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; justify-content: center; gap: 10px; }
        .btn:hover:not(:disabled) { transform: translateY(-2px); }
        .btn:disabled { opacity: 0.6; cursor: not-allowed; }
        .spinner { width: 20px; height: 20px; border: 3px solid rgba(255, 255, 255, 0.3); border-top-color: white; border-radius: 50%; animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .alert { padding: 16px 20px; border-radius: 12px; margin-bottom: 20px; display: flex; align-items: flex-start; gap: 12px; }
        .alert-success { background: rgba(34, 197, 94, 0.15); border: 1px solid rgba(34, 197, 94, 0.3); color: #86efac; }
        .alert-danger { background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: #fca5a5; }
        .alert i { font-size: 1.2rem; margin-top: 2px; }
        .back-link { text-align: center; margin-top: 20px; }
        .back-link a { color: #6366f1; text-decoration: none; font-size: 0.9rem; }
        .back-link a:hover { color: #8b5cf6; }
    </style>
</head>
<body>
            <?php include '../includes/lang-switcher.php'; ?>
    </div>
    <script src="../js/auto-translate.js"></script>

    <div class="container">
        <div class="card">
            <div class="brand">
                <div class="brand-icon">
                    <i class="fas fa-lock"></i>
                </div>
                <h1>تعيين كلمة مرور جديدة</h1>
                <p>أدخل كلمة المرور الجديدة</p>
            </div>
            
            <div id="alertContainer"></div>
            
            <?php if ($valid): ?>
            <form id="resetForm">
                <div class="form-group">
                    <label class="form-label">كلمة المرور الجديدة</label>
                    <div class="input-group">
                        <input type="password" name="password" class="form-control" placeholder="أدخل كلمة المرور الجديدة" required>
                        <i class="fas fa-lock"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">تأكيد كلمة المرور</label>
                    <div class="input-group">
                        <input type="password" name="confirm_password" class="form-control" placeholder="أعد إدخال كلمة المرور" required>
                        <i class="fas fa-lock"></i>
                    </div>
                </div>
                
                <button type="submit" class="btn" id="submitBtn">
                    <i class="fas fa-check"></i>
                    تحديث كلمة المرور
                </button>
            </form>
            <?php else: ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <div><?php echo htmlspecialchars($error); ?></div>
            </div>
            <?php endif; ?>
            
            <div class="back-link">
                <a href="login.php">العودة لتسجيل الدخول</a>
            </div>
        </div>
    </div>

    <script>
        <?php if ($valid): ?>
        document.getElementById('resetForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const btn = document.getElementById('submitBtn');
            const alert = document.getElementById('alertContainer');
            
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner"></div> جاري التحديث...';
            alert.innerHTML = '';
            
            try {
                const res = await fetch(window.location.href, {
                    method: 'POST',
                    body: new FormData(document.getElementById('resetForm'))
                });
                
                const data = await res.json();
                
                if (data.success) {
                    alert.innerHTML = `<div class="alert alert-success"><i class="fas fa-check-circle"></i><div>${data.message}</div></div>`;
                    document.getElementById('resetForm').style.display = 'none';
                    setTimeout(() => window.location.href = data.redirect, 2000);
                } else {
                    const msg = data.errors?.[0] || 'خطأ';
                    alert.innerHTML = `<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i><div>${msg}</div></div>`;
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-check"></i> تحديث كلمة المرور';
                }
            } catch (err) {
                alert.innerHTML = `<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i><div>حدث خطأ: ${err.message}</div></div>`;
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-check"></i> تحديث كلمة المرور';
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>