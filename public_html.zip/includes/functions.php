<?php
// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// تنظيف المدخلات
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// التحقق من تسجيل الدخول
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// التحقق من الأدمن
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// إعادة التوجيه
function redirect($url) {
    header("Location: $url");
    exit;
}

// رسالة فلاش
function setMessage($message, $type = 'success') {
    $_SESSION['message'] = $message;
    $_SESSION['message_type'] = $type;
}

function getMessage() {
    if (isset($_SESSION['message'])) {
        $msg = $_SESSION['message'];
        $type = $_SESSION['message_type'];
        unset($_SESSION['message'], $_SESSION['message_type']);
        return ['text' => $msg, 'type' => $type];
    }
    return null;
}

// الحصول على معلومات المحفظة
function getUserWallet($user_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM wallet WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $wallet = $stmt->fetch();
    
    // إذا لم توجد محفظة، أنشئ واحدة جديدة
    if (!$wallet) {
        $stmt = $conn->prepare("INSERT INTO wallet (user_id, available_balance, frozen_balance) VALUES (?, 0, 0)");
        $stmt->execute([$user_id]);
        
        // جلب المحفظة الجديدة
        $stmt = $conn->prepare("SELECT * FROM wallet WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $wallet = $stmt->fetch();
    }
    
    return $wallet;
}

// تسجيل معاملة مالية
function logTransaction($user_id, $type, $amount, $reference_id = null, $reference_type = null, $description = '') {
    global $conn;
    
    try {
        // جلب الرصيد قبل المعاملة
        $wallet = getUserWallet($user_id);
        $balance_before = $wallet['available_balance'] + $wallet['frozen_balance'];
        
        // إدراج المعاملة
        $stmt = $conn->prepare("
            INSERT INTO transactions 
            (user_id, type, amount, reference_id, reference_type, balance_before, description, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'completed')
        ");
        
        $stmt->execute([
            $user_id,
            $type,
            $amount,
            $reference_id,
            $reference_type,
            $balance_before,
            $description
        ]);
        
        $transaction_id = $conn->lastInsertId();
        
        // حساب الرصيد بعد المعاملة
        $wallet = getUserWallet($user_id);
        $balance_after = $wallet['available_balance'] + $wallet['frozen_balance'];
        
        // تحديث balance_after
        $stmt = $conn->prepare("UPDATE transactions SET balance_after = ? WHERE id = ?");
        $stmt->execute([$balance_after, $transaction_id]);
        
        return $transaction_id;
        
    } catch(PDOException $e) {
        return false;
    }
}

// الحصول على معلومات المستخدم الحالي
function getCurrentUser() {
    global $conn;
    
    if (!isLoggedIn()) {
        return null;
    }
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

// الحصول على بيانات المستخدم
function getUserData($user_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// التحقق من تحقق البريد الإلكتروني
function isEmailVerified($user_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT email_verified FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return $user && $user['email_verified'];
}

// تحويل الوقت لصيغة نسبية
function timeAgo($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    
    if ($diff->y > 0) return $diff->y . ' سنة';
    if ($diff->m > 0) return $diff->m . ' شهر';
    if ($diff->d > 0) return $diff->d . ' يوم';
    if ($diff->h > 0) return $diff->h . ' ساعة';
    if ($diff->i > 0) return $diff->i . ' دقيقة';
    return 'الآن';
}

// إرسال إشعار
function sendNotification($user_id, $title, $message, $type = 'system', $reference_id = null) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("
            INSERT INTO notifications (user_id, title, message, type, reference_id) 
            VALUES (?, ?, ?, ?, ?)
        ");
        return $stmt->execute([$user_id, $title, $message, $type, $reference_id]);
    } catch(PDOException $e) {
        return false;
    }
}

// ==================== نظام الترجمة التلقائي الكامل ====================

// تحديد اللغة الحالية
function getCurrentLanguage() {
    if (isset($_COOKIE['site_lang'])) {
        return $_COOKIE['site_lang'];
    }
    return 'ar';
}

// تغيير اللغة
function setLanguage($lang) {
    if (in_array($lang, ['ar', 'en', 'tr', 'de'])) {
        setcookie('site_lang', $lang, time() + (365 * 24 * 60 * 60), '/');
        $_SESSION['site_lang'] = $lang;
        return true;
    }
    return false;
}

// ترجمة نص واحد
function translateSingleText($text, $target_lang) {
    if ($target_lang === 'ar' || empty($text)) {
        return $text;
    }
    
    // المسار إلى ملف الكاش
    $cache_dir = __DIR__ . '/../cache';
    $cache_file = $cache_dir . "/trans_{$target_lang}.json";
    
    // إنشاء المجلد إذا لم يكن موجود
    if (!is_dir($cache_dir)) {
        @mkdir($cache_dir, 0755, true);
    }
    
    // تحميل الكاش
    $cache = [];
    if (file_exists($cache_file)) {
        $cache = json_decode(file_get_contents($cache_file), true) ?? [];
    }
    
    // التحقق من الكاش
    $key = md5($text);
    if (isset($cache[$key])) {
        return $cache[$key];
    }
    
    // محاولة الترجمة
    $translated = null;
    
    // الطريقة 1: MyMemory API
    try {
        $url = "https://api.mymemory.translated.net/get?q=" . urlencode($text) . "&langpair=ar|{$target_lang}";
        $response = @file_get_contents($url);
        if ($response) {
            $result = json_decode($response, true);
            if (isset($result['responseData']['translatedText'])) {
                $translated = $result['responseData']['translatedText'];
            }
        }
    } catch (Exception $e) {}
    
    // الطريقة 2: Google Translate (إذا فشلت الأولى)
    if (!$translated) {
        try {
            $url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=ar&tl={$target_lang}&dt=t&q=" . urlencode($text);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            curl_close($ch);
            
            if ($response) {
                $result = json_decode($response, true);
                if (isset($result[0][0][0])) {
                    $translated = $result[0][0][0];
                }
            }
        } catch (Exception $e) {}
    }
    
    // حفظ في الكاش
    if ($translated) {
        $cache[$key] = $translated;
        @file_put_contents($cache_file, json_encode($cache, JSON_UNESCAPED_UNICODE));
        return $translated;
    }
    
    return $text;
}

// معلومات اللغة الحالية
function getLangInfo() {
    $langs = [
        'ar' => ['name' => 'العربية', 'flag' => '🇸🇦', 'dir' => 'rtl', 'code' => 'ar'],
        'en' => ['name' => 'English', 'flag' => '🇬🇧', 'dir' => 'ltr', 'code' => 'en'],
        'tr' => ['name' => 'Türkçe', 'flag' => '🇹🇷', 'dir' => 'ltr', 'code' => 'tr'],
        'de' => ['name' => 'Deutsch', 'flag' => '🇩🇪', 'dir' => 'ltr', 'code' => 'de'],
    ];
    
    $current = getCurrentLanguage();
    return $langs[$current] ?? $langs['ar'];
}

// الحصول على كل اللغات
function getAllLanguages() {
    return [
        ['code' => 'ar', 'name' => 'العربية', 'flag' => '🇸🇦', 'dir' => 'rtl'],
        ['code' => 'en', 'name' => 'English', 'flag' => '🇬🇧', 'dir' => 'ltr'],
        ['code' => 'tr', 'name' => 'Türkçe', 'flag' => '🇹🇷', 'dir' => 'ltr'],
        ['code' => 'de', 'name' => 'Deutsch', 'flag' => '🇩🇪', 'dir' => 'ltr'],
    ];
}

// ✨ دالة سحرية - تترجم أي محتوى HTML تلقائياً
function autoTranslateHTML($html) {
    $lang = getCurrentLanguage();
    
    // إذا اللغة عربي، أرجع المحتوى كما هو
    if ($lang === 'ar') {
        return $html;
    }
    
    // استخراج كل النصوص العربية من HTML
    preg_match_all('/[\x{0600}-\x{06FF}\x{0750}-\x{077F}\x{08A0}-\x{08FF}\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]+(?:\s+[\x{0600}-\x{06FF}\x{0750}-\x{077F}\x{08A0}-\x{08FF}\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]+)*/u', $html, $matches);
    
    if (!empty($matches[0])) {
        $matches[0] = array_unique($matches[0]);
        
        foreach ($matches[0] as $arabic_text) {
            $arabic_text = trim($arabic_text);
            if (strlen($arabic_text) > 2) {
                $translated = translateSingleText($arabic_text, $lang);
                $html = str_replace($arabic_text, $translated, $html);
            }
        }
    }
    
    return $html;
}
require_once __DIR__ . '/subscriptions.php';

?>

