<?php
// التحقق من اشتراك المستخدم
function getUserSubscription($user_id) {
    global $conn;
    
    $stmt = $conn->prepare("
        SELECT us.*, sp.name as plan_name, sp.color, sp.icon
        FROM user_subscriptions us
        JOIN subscription_plans sp ON us.plan_id = sp.id
        WHERE us.user_id = ? 
        AND us.status = 'active'
        AND us.expires_at > NOW()
        ORDER BY us.expires_at DESC
        LIMIT 1
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

// الحصول على خطة المستخدم (أو المجانية)
function getUserPlan($user_id) {
    global $conn;
    
    $subscription = getUserSubscription($user_id);
    
    if ($subscription) {
        return $subscription['plan_id'];
    }
    
    return 1; // الخطة المجانية
}

// التحقق من ميزة
function hasFeature($user_id, $feature_key) {
    global $conn;
    
    $plan_id = getUserPlan($user_id);
    
    $stmt = $conn->prepare("
        SELECT feature_value FROM subscription_features 
        WHERE plan_id = ? AND feature_key = ? AND is_enabled = TRUE
    ");
    $stmt->execute([$plan_id, $feature_key]);
    $result = $stmt->fetch();
    
    return $result ? $result['feature_value'] : null;
}

// التحقق من الحد الأقصى
function checkLimit($user_id, $type) {
    global $conn;
    
    $limit = hasFeature($user_id, 'max_' . $type);
    
    if ($limit === 'غير محدود') {
        return true;
    }
    
    $limit = intval($limit);
    
    // حساب العدد الحالي
    if ($type === 'auctions') {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM auctions WHERE seller_id = ? AND status = 'active'");
    } elseif ($type === 'store_products') {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM store_products WHERE seller_id = ? AND status = 'active'");
    } else {
        return false;
    }
    
    $stmt->execute([$user_id]);
    $current = $stmt->fetch()['count'];
    
    return $current < $limit;
}

// الحصول على جميع الخطط
function getAllPlans() {
    global $conn;
    $stmt = $conn->query("SELECT * FROM subscription_plans WHERE is_active = TRUE ORDER BY display_order");
    return $stmt->fetchAll();
}

// الحصول على ميزات خطة
function getPlanFeatures($plan_id) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT * FROM subscription_features 
        WHERE plan_id = ? AND is_enabled = TRUE 
        ORDER BY display_order
    ");
    $stmt->execute([$plan_id]);
    return $stmt->fetchAll();
}

// شراء اشتراك
function purchaseSubscription($user_id, $plan_id, $duration = 'monthly') {
    global $conn;
    
    try {
        $conn->beginTransaction();
        
        // جلب الخطة
        $stmt = $conn->prepare("SELECT * FROM subscription_plans WHERE id = ?");
        $stmt->execute([$plan_id]);
        $plan = $stmt->fetch();
        
        if (!$plan) {
            throw new Exception('الخطة غير موجودة');
        }
        
        $price = $duration === 'yearly' ? $plan['price_yearly'] : $plan['price_monthly'];
        
        // التحقق من الرصيد
        $stmt = $conn->prepare("SELECT available_balance FROM wallet WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $wallet = $stmt->fetch();
        
        if ($wallet['available_balance'] < $price) {
            throw new Exception('رصيد غير كافٍ');
        }
        
        // خصم المبلغ
        $stmt = $conn->prepare("UPDATE wallet SET available_balance = available_balance - ? WHERE user_id = ?");
        $stmt->execute([$price, $user_id]);
        
        // حساب تاريخ الانتهاء
        $months = $duration === 'yearly' ? 12 : 1;
        $starts_at = date('Y-m-d H:i:s');
        $expires_at = date('Y-m-d H:i:s', strtotime("+$months months"));
        
        // إلغاء الاشتراك القديم
        $stmt = $conn->prepare("UPDATE user_subscriptions SET status = 'expired' WHERE user_id = ? AND status = 'active'");
        $stmt->execute([$user_id]);
        
        // إضافة اشتراك جديد
        $stmt = $conn->prepare("
            INSERT INTO user_subscriptions (user_id, plan_id, starts_at, expires_at, amount_paid, status) 
            VALUES (?, ?, ?, ?, ?, 'active')
        ");
        $stmt->execute([$user_id, $plan_id, $starts_at, $expires_at, $price]);
        
        // تحديث المستخدم
        $stmt = $conn->prepare("UPDATE users SET current_plan_id = ?, subscription_expires_at = ? WHERE id = ?");
        $stmt->execute([$plan_id, $expires_at, $user_id]);
        
        // تسجيل المعاملة
        logTransaction($user_id, 'subscription_purchase', $price, null, 'subscription', "اشتراك: {$plan['name']} - $duration");
        
        $conn->commit();
        return true;
        
    } catch (Exception $e) {
        $conn->rollBack();
        return $e->getMessage();
    }
}

// التحقق من الاشتراكات المنتهية
function checkExpiredSubscriptions() {
    global $conn;
    
    $stmt = $conn->query("
        UPDATE user_subscriptions 
        SET status = 'expired' 
        WHERE status = 'active' AND expires_at < NOW()
    ");
    
    $stmt = $conn->query("
        UPDATE users 
        SET current_plan_id = 1, subscription_expires_at = NULL 
        WHERE subscription_expires_at < NOW()
    ");
}

// ضمّنها في includes/functions.php
?>