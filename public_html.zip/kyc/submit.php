<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../auth/login.php');
}

$user_id = $_SESSION['user_id'];

// التحقق من الحالة الحالية
$stmt = $conn->prepare("SELECT kyc_status FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// إذا كان محققاً، عرض رسالة نجاح بدلاً من التوجيه
$is_verified = ($user['kyc_status'] == 'verified');

if ($is_verified) {
    $stmt = $conn->prepare("SELECT * FROM kyc_verifications WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $kyc = $stmt->fetch();
}

// السماح بإعادة الرفع فقط إذا كان مرفوضاً
if ($user['kyc_status'] == 'pending') {
    $stmt = $conn->prepare("SELECT * FROM kyc_verifications WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $kyc = $stmt->fetch();
    $can_resubmit = false;
} elseif ($user['kyc_status'] == 'rejected') {
    $stmt = $conn->prepare("SELECT * FROM kyc_verifications WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $kyc = $stmt->fetch();
    $can_resubmit = true;
} else {
    $can_resubmit = true;
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = clean($_POST['full_name']);
    $id_number = clean($_POST['id_number']);
    
    if (empty($full_name) || strlen($full_name) < 3) {
        $errors[] = 'الاسم الكامل يجب أن يكون 3 أحرف على الأقل';
    }
    
    if (empty($id_number)) {
        $errors[] = 'رقم الهوية مطلوب';
    }
    
    $required_images = ['id_front', 'id_back', 'selfie'];
    foreach ($required_images as $img) {
        if (empty($_FILES[$img]['name'])) {
            $errors[] = 'جميع الصور مطلوبة';
            break;
        }
    }
    
    if (empty($errors)) {
        $upload_dir = '../uploads/kyc/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $uploaded_files = [];
        
        try {
            foreach ($required_images as $img) {
                $file = $_FILES[$img];
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
                
                if (!in_array($ext, $allowed)) {
                    throw new Exception('نوع الملف غير مسموح');
                }
                
                if ($file['size'] > 5000000) {
                    throw new Exception('حجم الملف كبير جداً');
                }
                
                $new_name = $user_id . '_' . $img . '_' . time() . '.' . $ext;
                $destination = $upload_dir . $new_name;
                
                if (!move_uploaded_file($file['tmp_name'], $destination)) {
                    throw new Exception('فشل رفع الملف');
                }
                
                $uploaded_files[$img] = $destination;
            }
            
            $stmt = $conn->prepare("
                INSERT INTO kyc_verifications (user_id, full_name, id_number, id_front_image, id_back_image, selfie_image, status)
                VALUES (?, ?, ?, ?, ?, ?, 'pending')
                ON DUPLICATE KEY UPDATE
                full_name = VALUES(full_name),
                id_number = VALUES(id_number),
                id_front_image = VALUES(id_front_image),
                id_back_image = VALUES(id_back_image),
                selfie_image = VALUES(selfie_image),
                status = 'pending',
                submitted_at = CURRENT_TIMESTAMP
            ");
            
            $stmt->execute([
                $user_id,
                $full_name,
                $id_number,
                $uploaded_files['id_front'],
                $uploaded_files['id_back'],
                $uploaded_files['selfie']
            ]);
            
            $stmt = $conn->prepare("UPDATE users SET kyc_status = 'pending' WHERE id = ?");
            $stmt->execute([$user_id]);
            
            $success = 'تم رفع الوثائق بنجاح! سيتم مراجعتها خلال 24-48 ساعة';
            
        } catch (Exception $e) {
            $errors[] = 'خطأ: ' . $e->getMessage();
            
            foreach ($uploaded_files as $file) {
                if (file_exists($file)) {
                    unlink($file);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التحقق من الهوية - KYC</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
            direction: rtl;
        }
        .container { max-width: 900px; margin: 0 auto; }
        .kyc-card { 
            background: white; 
            border-radius: 20px; 
            padding: 50px; 
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .header { 
            text-align: center; 
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f1f5f9;
        }
        .header-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 2.5rem;
            color: white;
        }
        .header h1 { 
            color: #1e293b; 
            font-size: 2.2rem; 
            margin-bottom: 10px;
        }
        .header p { 
            color: #64748b; 
            font-size: 1.1rem; 
        }
        
        .status-box {
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .status-box-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            flex-shrink: 0;
        }
        .status-pending {
            background: #fef3c7;
            border: 2px solid #f59e0b;
        }
        .status-pending .status-box-icon {
            background: #fbbf24;
            color: white;
        }
        .status-rejected {
            background: #fee2e2;
            border: 2px solid #ef4444;
        }
        .status-rejected .status-box-icon {
            background: #ef4444;
            color: white;
        }
        .status-box-content h3 {
            margin-bottom: 8px;
            font-size: 1.3rem;
        }
        .status-pending h3 { color: #92400e; }
        .status-rejected h3 { color: #991b1b; }
        .status-box-content p {
            margin: 5px 0;
            line-height: 1.6;
        }
        .status-pending p { color: #78350f; }
        .status-rejected p { color: #7f1d1d; }
        
        .form-group { margin-bottom: 30px; }
        .form-group label { 
            display: block; 
            margin-bottom: 12px; 
            color: #1e293b; 
            font-weight: 600;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .form-group label i {
            color: #667eea;
        }
        .form-group input[type="text"] { 
            width: 100%; 
            padding: 15px 20px; 
            border: 2px solid #e2e8f0; 
            border-radius: 12px; 
            font-size: 1.05rem;
            transition: all 0.3s;
        }
        .form-group input:focus { 
            outline: none; 
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .file-upload {
            border: 3px dashed #cbd5e1;
            border-radius: 15px;
            padding: 35px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: #f8fafc;
        }
        .file-upload:hover { 
            border-color: #667eea; 
            background: #f1f5f9;
            transform: translateY(-2px);
        }
        .file-upload input { display: none; }
        .file-upload-icon { 
            font-size: 3.5rem; 
            margin-bottom: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .file-upload-text { 
            color: #475569; 
            font-size: 1rem;
            font-weight: 500;
        }
        
        .preview-image {
            margin-top: 20px;
            max-width: 100%;
            max-height: 200px;
            border-radius: 12px;
            display: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .instructions {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 35px;
            border: 1px solid #e2e8f0;
        }
        .instructions h3 { 
            color: #1e293b; 
            margin-bottom: 20px; 
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .instructions h3 i {
            color: #667eea;
        }
        .instructions ul { 
            padding-right: 25px; 
        }
        .instructions li { 
            color: #475569; 
            margin-bottom: 12px; 
            line-height: 1.8;
            display: flex;
            align-items: start;
            gap: 10px;
        }
        .instructions li::before {
            content: "✓";
            color: #10b981;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .alert { 
            padding: 18px 25px; 
            border-radius: 12px; 
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .alert i {
            font-size: 1.3rem;
        }
        .alert-success { 
            background: #d1fae5; 
            color: #065f46; 
            border-right: 4px solid #10b981; 
        }
        .alert-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border-right: 4px solid #dc2626; 
        }
        
        .btn { 
            width: 100%;
            padding: 18px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; 
            border: none; 
            border-radius: 12px; 
            font-size: 1.15rem; 
            font-weight: bold; 
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .btn:hover { 
            transform: translateY(-3px);
            box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
        }
        .btn:disabled {
            background: #cbd5e1;
            cursor: not-allowed;
            transform: none;
        }
        .btn i {
            font-size: 1.2rem;
        }
        
        .back-link {
            text-align: center;
            margin-top: 25px;
        }
        .back-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }
        .back-link a:hover {
            gap: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="kyc-card">
            <div class="header">
                <div class="header-icon">
                    <i class="fas fa-id-card"></i>
                </div>
                <h1>التحقق من الهوية</h1>
                <p>للحفاظ على أمان المنصة، يجب التحقق من هويتك</p>
            </div>
<?php if ($is_verified): ?>
    <div style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); border: 3px solid #10b981; border-radius: 20px; padding: 40px; margin-bottom: 30px; text-align: center;">
        <div style="width: 100px; height: 100px; background: #10b981; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 3.5rem; color: white; box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);">
            <i class="fas fa-check-circle"></i>
        </div>
        <h2 style="color: #065f46; margin-bottom: 15px; font-size: 2rem;">حسابك محقق بنجاح!</h2>
        <p style="color: #047857; font-size: 1.1rem; margin-bottom: 20px;">يمكنك الآن البيع والشراء بحرية تامة</p>
        
        <div style="background: white; border-radius: 15px; padding: 25px; margin-top: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
            <h4 style="color: #1e293b; margin-bottom: 20px; display: flex; align-items: center; justify-content: center; gap: 10px;">
                <i class="fas fa-folder-open"></i> المستندات المرفوعة
            </h4>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                <div>
                    <p style="font-size: 0.9rem; color: #64748b; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-id-card"></i> الهوية (أمامي)
                    </p>
                    <a href="<?php echo htmlspecialchars($kyc['id_front_image']); ?>" target="_blank">
                        <img src="<?php echo htmlspecialchars($kyc['id_front_image']); ?>" 
                             style="width: 100%; height: 120px; object-fit: cover; border-radius: 10px; border: 3px solid #10b981; cursor: pointer; transition: 0.3s;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="this.parentElement.innerHTML='<div style=\'height:120px;background:#f1f5f9;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#64748b;\'><i class=\'fas fa-file-pdf fa-3x\'></i></div>'">
                    </a>
                </div>
                <div>
                    <p style="font-size: 0.9rem; color: #64748b; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-id-card"></i> الهوية (خلفي)
                    </p>
                    <a href="<?php echo htmlspecialchars($kyc['id_back_image']); ?>" target="_blank">
                        <img src="<?php echo htmlspecialchars($kyc['id_back_image']); ?>" 
                             style="width: 100%; height: 120px; object-fit: cover; border-radius: 10px; border: 3px solid #10b981; cursor: pointer; transition: 0.3s;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="this.parentElement.innerHTML='<div style=\'height:120px;background:#f1f5f9;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#64748b;\'><i class=\'fas fa-file-pdf fa-3x\'></i></div>'">
                    </a>
                </div>
                <div>
                    <p style="font-size: 0.9rem; color: #64748b; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-camera"></i> الصورة الشخصية
                    </p>
                    <a href="<?php echo htmlspecialchars($kyc['selfie_image']); ?>" target="_blank">
                        <img src="<?php echo htmlspecialchars($kyc['selfie_image']); ?>" 
                             style="width: 100%; height: 120px; object-fit: cover; border-radius: 10px; border: 3px solid #10b981; cursor: pointer; transition: 0.3s;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'">
                    </a>
                </div>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background: #f8fafc; border-radius: 10px;">
                <p style="color: #64748b; font-size: 0.95rem; margin: 0;">
                    <i class="fas fa-user"></i> <strong>الاسم:</strong> <?php echo htmlspecialchars($kyc['full_name']); ?><br>
                    <i class="fas fa-id-badge"></i> <strong>رقم الهوية:</strong> <?php echo htmlspecialchars($kyc['id_number']); ?><br>
                    <i class="fas fa-calendar-check"></i> <strong>تاريخ التحقق:</strong> <?php echo date('Y-m-d H:i', strtotime($kyc['reviewed_at'])); ?>
                </p>
            </div>
        </div>
        
        <div style="margin-top: 25px;">
            <a href="../dashboard.php" class="btn" style="width: auto; display: inline-flex; padding: 15px 35px;">
                <i class="fas fa-home"></i> العودة للوحة التحكم
            </a>
        </div>
    </div>
    
    <?php 
    // إخفاء باقي الصفحة إذا كان موثقاً
    echo '</div></div></body></html>';
    exit;
    ?>
<?php endif; ?>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <ul style="margin: 0; padding-right: 20px;">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if ($user['kyc_status'] == 'pending'): ?>
                <div class="status-box status-pending">
                    <div class="status-box-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="status-box-content">
                        <h3>طلبك قيد المراجعة</h3>
                        <p>تم رفع وثائقك بنجاح وسيتم مراجعتها خلال 24-48 ساعة</p>
                        <p style="font-size: 0.9rem; margin-top: 8px;">
                            <i class="fas fa-calendar"></i> تاريخ الرفع: <?php echo date('Y-m-d H:i', strtotime($kyc['submitted_at'])); ?>
                        </p>
                    </div>
                </div>
            <?php elseif ($user['kyc_status'] == 'rejected'): ?>
                <div class="status-box status-rejected">
                    <div class="status-box-icon">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="status-box-content">
                        <h3>تم رفض طلبك</h3>
                        <p><strong><i class="fas fa-info-circle"></i> السبب:</strong> <?php echo htmlspecialchars($kyc['rejection_reason'] ?? 'غير محدد'); ?></p>
                        <p style="margin-top: 10px;">يمكنك إعادة رفع الوثائق بشكل صحيح</p>
                    </div>
                </div>
            <?php endif; ?>

            <div class="instructions">
                <h3><i class="fas fa-info-circle"></i> تعليمات مهمة</h3>
                <ul style="list-style: none;">
                    <li>يجب أن تكون جميع الصور واضحة وقابلة للقراءة</li>
                    <li>الهوية يجب أن تكون سارية المفعول</li>
                    <li>الصورة الشخصية يجب أن تكون حديثة وواضحة الوجه</li>
                    <li>الحد الأقصى لحجم كل صورة: 5 ميجابايت</li>
                    <li>الصيغ المسموحة: JPG, PNG, PDF</li>
                </ul>
            </div>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> الاسم الكامل (كما في الهوية)</label>
                    <input type="text" name="full_name" required 
                           value="<?php echo isset($kyc) ? htmlspecialchars($kyc['full_name']) : ''; ?>"
                           placeholder="أدخل اسمك الكامل">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-id-card-alt"></i> رقم الهوية</label>
                    <input type="text" name="id_number" required 
                           value="<?php echo isset($kyc) ? htmlspecialchars($kyc['id_number']) : ''; ?>"
                           placeholder="أدخل رقم الهوية">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-image"></i> صورة الهوية (الوجه الأمامي)</label>
                    <div class="file-upload" onclick="document.getElementById('id_front').click()">
                        <div class="file-upload-icon"><i class="fas fa-file-upload"></i></div>
                        <div class="file-upload-text">انقر لرفع صورة الوجه الأمامي للهوية</div>
                        <input type="file" id="id_front" name="id_front" accept="image/*,application/pdf" 
                               onchange="previewImage(this, 'preview_front')" required>
                    </div>
                    <img id="preview_front" class="preview-image">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-image"></i> صورة الهوية (الوجه الخلفي)</label>
                    <div class="file-upload" onclick="document.getElementById('id_back').click()">
                        <div class="file-upload-icon"><i class="fas fa-file-upload"></i></div>
                        <div class="file-upload-text">انقر لرفع صورة الوجه الخلفي للهوية</div>
                        <input type="file" id="id_back" name="id_back" accept="image/*,application/pdf" 
                               onchange="previewImage(this, 'preview_back')" required>
                    </div>
                    <img id="preview_back" class="preview-image">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-camera"></i> صورة شخصية (سيلفي) واضحة</label>
                    <div class="file-upload" onclick="document.getElementById('selfie').click()">
                        <div class="file-upload-icon"><i class="fas fa-portrait"></i></div>
                        <div class="file-upload-text">انقر لرفع صورة شخصية واضحة</div>
                        <input type="file" id="selfie" name="selfie" accept="image/*" 
                               onchange="previewImage(this, 'preview_selfie')" required>
                    </div>
                    <img id="preview_selfie" class="preview-image">
                </div>

                <?php if ($can_resubmit || $user['kyc_status'] == 'unverified'): ?>
                    <button type="submit" class="btn">
                        <i class="fas fa-paper-plane"></i>
                        <?php echo $user['kyc_status'] == 'rejected' ? 'إعادة إرسال الوثائق' : 'إرسال الوثائق للمراجعة'; ?>
                    </button>
                <?php else: ?>
                    <div style="background: #fef3c7; color: #92400e; padding: 18px; border-radius: 12px; text-align: center; margin-bottom: 20px; display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <i class="fas fa-hourglass-half"></i>
                        <span>طلبك قيد المراجعة. لا يمكن إعادة الرفع حالياً.</span>
                    </div>
                    <button type="button" class="btn" disabled>
                        <i class="fas fa-lock"></i>
                        إرسال الوثائق للمراجعة
                    </button>
                <?php endif; ?>
            </form>

            <div class="back-link">
                <a href="../dashboard.php">
                    <i class="fas fa-arrow-right"></i> العودة للوحة التحكم
                </a>
            </div>
        </div>
    </div>

    <script>
        function previewImage(input, previewId) {
            const preview = document.getElementById(previewId);
            const file = input.files[0];
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>