<?php
session_start();

// حذف جميع متغيرات الجلسة
$_SESSION = array();

// حذف ملف تعريف الارتباط للجلسة
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time()-3600, '/');
}

// حذف كوكيز "تذكرني" إن وجدت
if (isset($_COOKIE['remember_user'])) {
    setcookie('remember_user', '', time()-3600, '/');
}

// إنهاء الجلسة
session_destroy();

// إعادة التوجيه للصفحة الرئيسية
header("Location: ../index.php");
exit;
?>