<?php
// Hostinger SMTP Configuration
function sendEmail($to, $subject, $body, $isHtml = true) {
    $mail_headers = "MIME-Version: 1.0\r\n";
    $mail_headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $mail_headers .= "From: noreply@bidora.de\r\n";
    $mail_headers .= "Reply-To: support@bidora.de\r\n";
    
    return mail($to, $subject, $body, $mail_headers);
}

// أو باستخدام SMTP للموثوقية العالية
function sendEmailViaSMTP($to, $subject, $body, $isHtml = true) {
    require_once 'PHPMailer/PHPMailer.php';
    require_once 'PHPMailer/SMTP.php';
    require_once 'PHPMailer/Exception.php';
    
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    
    try {
        // إعدادات Hostinger SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.hostinger.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'noreply@bidora.de';
        $mail->Password = 'Yazenstars1@';
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        $mail->setFrom('noreply@bidora.de', 'مزادات السيارات');
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->isHTML($isHtml);
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Mail Error: " . $mail->ErrorInfo);
        return false;
    }
}
?>