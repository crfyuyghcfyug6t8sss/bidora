<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$chat_id = isset($_GET['chat_id']) ? (int)$_GET['chat_id'] : 0;
$last_id = isset($_GET['last_id']) ? (int)$_GET['last_id'] : 0;
$user_id = $_SESSION['user_id'];

// التحقق من الصلاحية
$stmt = $conn->prepare("SELECT id FROM sale_chats WHERE id = ? AND (seller_id = ? OR buyer_id = ?)");
$stmt->execute([$chat_id, $user_id, $user_id]);
if (!$stmt->fetch()) {
    echo json_encode(['error' => 'Access denied']);
    exit;
}

// جلب رسائل جديدة
$stmt = $conn->prepare("
    SELECT 
        m.*,
        u.username,
        CASE WHEN m.sender_id = ? THEN 1 ELSE 0 END as is_mine
    FROM sale_messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.chat_id = ? AND m.id > ?
    ORDER BY m.created_at ASC
");
$stmt->execute([$user_id, $chat_id, $last_id]);
$messages = $stmt->fetchAll();

// تحديث كمقروء
if (!empty($messages)) {
    $stmt = $conn->prepare("
        UPDATE sale_messages 
        SET is_read = TRUE 
        WHERE chat_id = ? AND id > ? AND sender_id != ?
    ");
    $stmt->execute([$chat_id, $last_id, $user_id]);
}

// تنسيق البيانات
$formatted = [];
foreach ($messages as $msg) {
    $formatted[] = [
        'id' => (int)$msg['id'],
        'message' => htmlspecialchars($msg['message']),
        'username' => $msg['username'],
        'is_mine' => (bool)$msg['is_mine'],
        'time' => date('H:i', strtotime($msg['created_at'])),
        'message_type' => $msg['message_type'],
        'voice_message' => $msg['voice_message']
    ];
}

echo json_encode(['messages' => $formatted]);