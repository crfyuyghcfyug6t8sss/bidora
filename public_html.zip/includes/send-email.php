<?php
// إذا كنت تستخدم PHP mail() البسيط (بدون PHPMailer)
function sendEmailViaSMTP($to, $subject, $body, $isHtml = true) {
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: noreply@bidora.de\r\n";
    $headers .= "Reply-To: support@bidora.de\r\n";
    
    return mail($to, $subject, $body, $headers);
}

// أو إذا كنت تستخدم PHPMailer (موصى به)
function sendEmailViaSMTPMailer($to, $subject, $body, $isHtml = true) {
    try {
        require_once 'PHPMailer/PHPMailer.php';
        require_once 'PHPMailer/SMTP.php';
        require_once 'PHPMailer/Exception.php';
        
        $mail = new PHPMailer\PHPMailer\PHPMailer();
        
        // إعدادات Hostinger
        $mail->isSMTP();
        $mail->Host = 'smtp.hostinger.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'noreply@bidora.de'; // غيّر هذا
        $mail->Password = 'Yazenstars1@';         // غيّر هذا
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        $mail->setFrom('noreply@bidora.de', 'مزادات السيارات');
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->isHTML($isHtml);
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Email Error: " . $e->getMessage());
        return false;
    }
}
?>