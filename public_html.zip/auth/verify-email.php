<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';
require_once '../includes/functions.php';

// التحقق من وجود التوكن
if (!isset($_GET['token']) || empty($_GET['token'])) {
    header('Location: ../index.php');
    exit;
}

$token = trim($_GET['token']);
$success = false;
$message = '';
$error_type = '';

try {
    // جلب معلومات التحقق
    $stmt = $conn->prepare("
        SELECT ev.*, u.id as user_id, u.email, u.username, u.email_verified
        FROM email_verifications ev
        JOIN users u ON ev.user_id = u.id
        WHERE ev.token = ? AND ev.verified_at IS NULL
        LIMIT 1
    ");
    $stmt->execute([$token]);
    $verification = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$verification) {
        // التوكن غير موجود أو تم استخدامه بالفعل
        $stmt = $conn->prepare("SELECT id FROM email_verifications WHERE token = ? LIMIT 1");
        $stmt->execute([$token]);
        $used_token = $stmt->fetch();
        
        if ($used_token) {
            $error_type = 'already_verified';
            $message = 'تم التحقق من هذا البريد مسبقاً';
        } else {
            $error_type = 'invalid_token';
            $message = 'الرابط غير صحيح';
        }
    } else {
        // التحقق من صلاحية التوكن
        $expiry = new DateTime($verification['expires_at']);
        $now = new DateTime();
        
        if ($now > $expiry) {
            $error_type = 'expired';
            $message = 'انتهت صلاحية الرابط';
        } else {
            // التحقق ناجح - تحديث حالة المستخدم
            $conn->beginTransaction();
            
            try {
                // تحديث حالة المستخدم
                $update_user = $conn->prepare("
                    UPDATE users 
                    SET email_verified = TRUE, email_verified_at = NOW() 
                    WHERE id = ?
                ");
                $update_user->execute([$verification['user_id']]);
                
                // تحديث رمز التحقق
                $update_verification = $conn->prepare("
                    UPDATE email_verifications 
                    SET verified_at = NOW() 
                    WHERE token = ?
                ");
                $update_verification->execute([$token]);
                
                $conn->commit();
                
                // تسجيل الدخول التلقائي
                $_SESSION['user_id'] = $verification['user_id'];
                $_SESSION['username'] = $verification['username'];
                $_SESSION['email'] = $verification['email'];
                $_SESSION['role'] = 'user';
                $_SESSION['logged_in'] = true;
                
                // إرسال إشعار بالنجاح
                sendNotification(
                    $verification['user_id'], 
                    'تم التحقق من بريدك بنجاح', 
                    'مرحباً بك في مزادات السيارات! تم تفعيل حسابك بنجاح.',
                    'system'
                );
                
                $success = true;
                $message = 'تم التحقق من بريدك بنجاح!';
                
            } catch (Exception $e) {
                $conn->rollBack();
                throw $e;
            }
        }
    }
    
} catch(PDOException $e) {
    error_log("Verification Error: " . $e->getMessage());
    $error_type = 'server_error';
    $message = 'حدث خطأ في التحقق. يرجى المحاولة لاحقاً';
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التحقق من البريد الإلكتروني - مزادات السيارات</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Cairo', sans-serif;
            background: #0f172a;
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 20px;
            direction: rtl;
            overflow-x: hidden;
        }
        
        /* الجزيئات المتحركة */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            pointer-events: none;
            z-index: 0;
        }
        
        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: rgba(99, 102, 241, 0.5);
            border-radius: 50%;
            animation: float linear infinite;
        }
        
        @keyframes float {
            0% {
                transform: translateY(100vh) rotate(0deg);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100vh) rotate(360deg);
                opacity: 0;
            }
        }
        
        .container {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 550px;
        }
        
        .card {
            background: rgba(30, 41, 59, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(148, 163, 184, 0.1);
            border-radius: 24px;
            padding: 50px 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            text-align: center;
            animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* الأيقونة */
        .icon-wrapper {
            margin-bottom: 30px;
            position: relative;
            display: inline-block;
        }
        
        .icon-circle {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            position: relative;
            animation: scaleIn 0.6s ease-out;
        }
        
        @keyframes scaleIn {
            from {
                transform: scale(0);
                opacity: 0;
            }
            to {
                transform: scale(1);
                opacity: 1;
            }
        }
        
        .icon-circle.success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            box-shadow: 0 20px 50px rgba(16, 185, 129, 0.4);
            animation: scaleIn 0.6s ease-out, pulse 2s ease-in-out infinite;
        }
        
        .icon-circle.error {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            box-shadow: 0 20px 50px rgba(239, 68, 68, 0.4);
            animation: scaleIn 0.6s ease-out, shake 0.5s ease-in-out;
        }
        
        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
                box-shadow: 0 20px 50px rgba(16, 185, 129, 0.4);
            }
            50% {
                transform: scale(1.05);
                box-shadow: 0 25px 60px rgba(16, 185, 129, 0.6);
            }
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }
        
        .icon-circle::before {
            content: '';
            position: absolute;
            top: -15px;
            left: -15px;
            right: -15px;
            bottom: -15px;
            border: 3px dashed;
            border-radius: 50%;
            animation: rotate 20s linear infinite;
        }
        
        .icon-circle.success::before {
            border-color: rgba(16, 185, 129, 0.3);
        }
        
        .icon-circle.error::before {
            border-color: rgba(239, 68, 68, 0.3);
        }
        
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .icon-circle i {
            font-size: 4rem;
            color: white;
            z-index: 1;
        }
        
        /* العنوان والرسالة */
        h1 {
            color: #f1f5f9;
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 15px;
        }
        
        h1.success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        h1.error {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .message {
            color: #cbd5e1;
            font-size: 1.1rem;
            line-height: 1.8;
            margin-bottom: 30px;
        }
        
        /* صندوق المعلومات */
        .info-box {
            background: rgba(15, 23, 42, 0.5);
            border: 2px solid rgba(99, 102, 241, 0.3);
            border-radius: 15px;
            padding: 20px;
            margin: 25px 0;
            text-align: right;
        }
        
        .info-box.success {
            background: rgba(16, 185, 129, 0.1);
            border-color: rgba(16, 185, 129, 0.3);
        }
        
        .info-box.error {
            background: rgba(239, 68, 68, 0.1);
            border-color: rgba(239, 68, 68, 0.3);
        }
        
        .info-box p {
            color: #cbd5e1;
            line-height: 1.8;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .info-box i {
            color: #6366f1;
            font-size: 1.2rem;
        }
        
        .info-box.success i {
            color: #10b981;
        }
        
        .info-box.error i {
            color: #ef4444;
        }
        
        /* الأزرار */
        .actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 30px;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 16px 30px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.05rem;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
            font-family: 'Cairo', sans-serif;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            color: white;
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(99, 102, 241, 0.4);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
        }
        
        .btn-success:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(16, 185, 129, 0.4);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            box-shadow: 0 8px 20px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(239, 68, 68, 0.4);
        }
        
        .btn-secondary {
            background: rgba(15, 23, 42, 0.5);
            color: #94a3b8;
            border: 2px solid rgba(148, 163, 184, 0.2);
        }
        
        .btn-secondary:hover {
            background: rgba(15, 23, 42, 0.8);
            border-color: rgba(148, 163, 184, 0.3);
            transform: translateY(-2px);
        }
        
        /* مؤقت العد التنازلي */
        .countdown {
            color: #94a3b8;
            font-size: 0.9rem;
            margin-top: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .countdown i {
            animation: spin 2s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* التذييل */
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid rgba(148, 163, 184, 0.1);
        }
        
        .footer p {
            color: #64748b;
            font-size: 0.85rem;
        }
        
        .footer a {
            color: #6366f1;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }
        
        .footer a:hover {
            color: #8b5cf6;
        }
        
        /* الاستجابة */
        @media (max-width: 600px) {
            .card {
                padding: 40px 25px;
            }
            
            h1 {
                font-size: 1.6rem;
            }
            
            .icon-circle {
                width: 110px;
                height: 110px;
            }
            
            .icon-circle i {
                font-size: 3rem;
            }
            
            .btn {
                padding: 14px 20px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
            <?php include '../includes/lang-switcher.php'; ?>
    </div>
    <script src="../js/auto-translate.js"></script>

    <div class="particles" id="particles"></div>
    
    <div class="container">
        <div class="card">
            <!-- الأيقونة -->
            <div class="icon-wrapper">
                <div class="icon-circle <?php echo $success ? 'success' : 'error'; ?>">
                    <i class="fas fa-<?php echo $success ? 'check-circle' : 'times-circle'; ?>"></i>
                </div>
            </div>
            
            <!-- العنوان -->
            <h1 class="<?php echo $success ? 'success' : 'error'; ?>">
                <?php echo $success ? 'تم التحقق بنجاح!' : 'خطأ في التحقق'; ?>
            </h1>
            
            <!-- الرسالة -->
            <p class="message"><?php echo htmlspecialchars($message); ?></p>
            
            <!-- معلومات إضافية -->
            <?php if ($success): ?>
                <div class="info-box success">
                    <p>
                        <i class="fas fa-check-circle"></i>
                        تم تفعيل حسابك بنجاح! يمكنك الآن الاستفادة من جميع ميزات المنصة
                    </p>
                </div>
            <?php elseif ($error_type == 'expired'): ?>
                <div class="info-box error">
                    <p>
                        <i class="fas fa-clock"></i>
                        انتهت صلاحية رابط التحقق. يرجى طلب رابط جديد
                    </p>
                </div>
            <?php elseif ($error_type == 'already_verified'): ?>
                <div class="info-box success">
                    <p>
                        <i class="fas fa-info-circle"></i>
                        حسابك محقق بالفعل. يمكنك تسجيل الدخول مباشرة
                    </p>
                </div>
            <?php endif; ?>
            
            <!-- الأزرار -->
            <div class="actions">
                <?php if ($success): ?>
                    <a href="../dashboard.php" class="btn btn-success">
                        <i class="fas fa-tachometer-alt"></i>
                        الذهاب للوحة التحكم
                    </a>
                    
                    <div class="countdown">
                        <i class="fas fa-spinner"></i>
                        سيتم التحويل تلقائياً خلال <span id="countdown">3</span> ثوانٍ
                    </div>
                <?php elseif ($error_type == 'expired'): ?>
                    <a href="../verify-pending.php" class="btn btn-danger">
                        <i class="fas fa-redo"></i>
                        إعادة إرسال رابط التحقق
                    </a>
                    <a href="login.php" class="btn btn-secondary">
                        <i class="fas fa-sign-in-alt"></i>
                        تسجيل الدخول
                    </a>
                <?php elseif ($error_type == 'already_verified'): ?>
                    <a href="login.php" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt"></i>
                        تسجيل الدخول
                    </a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-primary">
                        <i class="fas fa-user-plus"></i>
                        إنشاء حساب جديد
                    </a>
                    <a href="login.php" class="btn btn-secondary">
                        <i class="fas fa-sign-in-alt"></i>
                        تسجيل الدخول
                    </a>
                <?php endif; ?>
            </div>
            
            <!-- التذييل -->
            <div class="footer">
                <p>
                    هل تحتاج مساعدة؟ 
                    <a href="mailto:support@bidora.de">تواصل مع الدعم</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        // إنشاء الجزيئات المتحركة
        function createParticles() {
            const container = document.getElementById('particles');
            for (let i = 0; i < 50; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 10 + 10) + 's';
                particle.style.animationDelay = Math.random() * 5 + 's';
                container.appendChild(particle);
            }
        }
        createParticles();
        
        <?php if ($success): ?>
        // العد التنازلي التلقائي
        let countdown = 3;
        const countdownElement = document.getElementById('countdown');
        
        const timer = setInterval(() => {
            countdown--;
            if (countdownElement) {
                countdownElement.textContent = countdown;
            }
            
            if (countdown <= 0) {
                clearInterval(timer);
                window.location.href = '../dashboard.php';
            }
        }, 1000);
        <?php endif; ?>
    </script>
</body>
</html>