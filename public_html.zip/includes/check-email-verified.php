<?php
// يمكنك إضافة هذا في dashboard.php للتحقق من تحقق البريد
function checkEmailVerified() {
    global $conn;
    
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    $stmt = $conn->prepare("SELECT email_verified FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $user && $user['email_verified'];
}

// في dashboard.php بعد التحقق من الجلسة:
if (!checkEmailVerified()) {
    echo "<div class='alert alert-warning'>
            <i class='fas fa-exclamation-circle'></i>
            يرجى التحقق من بريدك الإلكتروني. 
            <a href='auth/resend-verification.php'>إعادة إرسال</a>
          </div>";
}
?>