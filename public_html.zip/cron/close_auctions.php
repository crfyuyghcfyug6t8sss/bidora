<?php
// منع الوصول المباشر من المتصفح
if (php_sapi_name() !== 'cli' && !isset($_GET['manual_run'])) {
    die('Access denied');
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

echo "[" . date('Y-m-d H:i:s') . "] بدء عملية إغلاق المزادات...\n";

try {
    // جلب المزادات المنتهية والنشطة
    $stmt = $conn->query("
        SELECT * FROM auctions 
        WHERE status = 'active' 
        AND end_time <= NOW()
    ");
    
    $expired_auctions = $stmt->fetchAll();
    $closed_count = 0;
    
    foreach ($expired_auctions as $auction) {
        echo "\n--- معالجة المزاد #{$auction['id']} ---\n";
        
        try {
            $conn->beginTransaction();
            
            // إذا كان هناك فائز
            if ($auction['highest_bidder_id']) {
                $winner_id = $auction['highest_bidder_id'];
                $final_price = $auction['current_price'];
                $seller_id = $auction['seller_id'];
                
                echo "الفائز: مستخدم #{$winner_id} بمبلغ {$final_price}$\n";
                
                // 1. حساب العمولة من الشرائح السعرية
                $stmt_tier = $conn->prepare("
                    SELECT commission_rate 
                    FROM commission_tiers 
                    WHERE ? BETWEEN min_price AND max_price 
                    LIMIT 1
                ");
                $stmt_tier->execute([$final_price]);
                $tier = $stmt_tier->fetch();
                
                if ($tier) {
                    $commission_rate = $tier['commission_rate'] / 100;
                } else {
                    $commission_rate = 0.05; // 5%
                }
                
                $commission = $final_price * $commission_rate;
                $seller_amount = $final_price - $commission;
                
                echo "المبلغ الإجمالي: {$final_price}$\n";
                echo "الشريحة السعرية: " . ($commission_rate * 100) . "%\n";
                echo "العمولة: {$commission}$\n";
                echo "مبلغ البائع (محجوز): {$seller_amount}$\n";
                
                // 2. خصم المبلغ المحجوز من الفائز
                $stmt = $conn->prepare("
                    UPDATE wallet 
                    SET frozen_balance = frozen_balance - ? 
                    WHERE user_id = ?
                ");
                $stmt->execute([$final_price, $winner_id]);
                
                logTransaction($winner_id, 'bid_deduct', $final_price, $auction['id'], 'auction', 'خصم نهائي - فوز بالمزاد');
                
                // 3. حجز المبلغ للبائع في sales_hold_balance بدلاً من إضافته مباشرة
                $stmt = $conn->prepare("
                    UPDATE wallet 
                    SET sales_hold_balance = sales_hold_balance + ? 
                    WHERE user_id = ?
                ");
                $stmt->execute([$seller_amount, $seller_id]);
                
                logTransaction($seller_id, 'sales_hold', $seller_amount, $auction['id'], 'auction', 'رصيد محجوز من بيع - بانتظار تأكيد الاستلام');
                logTransaction($seller_id, 'commission', $commission, $auction['id'], 'auction', 'عمولة الموقع (' . ($commission_rate * 100) . '%)');
                
                // 4. إنشاء سجل تأكيد البيع
                $stmt = $conn->prepare("
                    INSERT INTO sales_confirmations (auction_id, seller_id, buyer_id, sale_amount, commission_amount, seller_net_amount, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'pending')
                ");
                $stmt->execute([$auction['id'], $seller_id, $winner_id, $final_price, $commission, $seller_amount]);
                // إنشاء شات بين البائع والمشتري
try {
    $stmt = $conn->prepare("
        INSERT INTO sale_chats (sale_confirmation_id, auction_id, seller_id, buyer_id)
        SELECT id, ?, ?, ? FROM sales_confirmations WHERE auction_id = ? LIMIT 1
    ");
    $stmt->execute([$auction['id'], $seller_id, $winner_id, $auction['id']]);
    echo "تم إنشاء شات بين البائع والمشتري\n";
} catch(PDOException $e) {
    echo "تحذير: لم يتم إنشاء الشات (ربما موجود مسبقاً)\n";
}
                
                echo "تم حجز مبلغ البائع في sales_hold_balance\n";
                
                // 5. تحديث حالة مزايدة الفائز
                $stmt = $conn->prepare("
                    UPDATE bids 
                    SET status = 'won' 
                    WHERE auction_id = ? AND user_id = ? AND status = 'active'
                ");
                $stmt->execute([$auction['id'], $winner_id]);
                
                // 6. إلغاء حجز رصيد الخاسرين
                $stmt = $conn->prepare("
                    SELECT * FROM bids 
                    WHERE auction_id = ? AND user_id != ? AND status = 'active'
                ");
                $stmt->execute([$auction['id'], $winner_id]);
                $losing_bids = $stmt->fetchAll();
                
                foreach ($losing_bids as $bid) {
                    $stmt = $conn->prepare("
                        UPDATE wallet 
                        SET available_balance = available_balance + ?,
                            frozen_balance = frozen_balance - ?
                        WHERE user_id = ?
                    ");
                    $stmt->execute([$bid['frozen_amount'], $bid['frozen_amount'], $bid['user_id']]);
                    
                    $stmt = $conn->prepare("
                        UPDATE bids 
                        SET status = 'outbid' 
                        WHERE id = ?
                    ");
                    $stmt->execute([$bid['id']]);
                    
                    logTransaction($bid['user_id'], 'bid_release', $bid['frozen_amount'], $auction['id'], 'auction', 'إلغاء حجز - انتهاء المزاد');
                    
                    echo "تم إلغاء حجز {$bid['frozen_amount']}$ من مستخدم #{$bid['user_id']}\n";
                }
                
                // 7. تحديث حالة المزاد
                $stmt = $conn->prepare("
                    UPDATE auctions 
                    SET status = 'completed' 
                    WHERE id = ?
                ");
                $stmt->execute([$auction['id']]);
                
                // 8. إرسال إشعارات
                sendNotification($winner_id, 'مبروك! فزت بالمزاد', 'لقد فزت بالمزاد. يرجى تأكيد استلام السيارة عند الوصول', 'won', $auction['id']);
                sendNotification($seller_id, 'تم بيع سيارتك', 'تم بيع سيارتك بمبلغ ' . $final_price . '$. المبلغ محجوز وسيتم تحريره عند تأكيد المشتري للاستلام', 'auction_end', $auction['id']);
                
                // 9. إنشاء طلبات التقييم
                try {
                    $stmt = $conn->prepare("
                        INSERT INTO ratings (auction_id, from_user_id, to_user_id) 
                        VALUES (?, ?, ?)
                    ");
                    $stmt->execute([$auction['id'], $winner_id, $seller_id]);
                    $stmt->execute([$auction['id'], $seller_id, $winner_id]);
                    echo "تم إنشاء طلبات التقييم\n";
                } catch(PDOException $e) {
                    echo "تحذير: لم يتم إنشاء طلبات التقييم (ربما موجودة مسبقاً)\n";
                }
                
                echo "✅ تم إغلاق المزاد بنجاح - المبلغ محجوز بانتظار التأكيد\n";
                
            } else {
                // لا يوجد فائز
                $stmt = $conn->prepare("
                    UPDATE auctions 
                    SET status = 'expired' 
                    WHERE id = ?
                ");
                $stmt->execute([$auction['id']]);
                
                sendNotification($auction['seller_id'], 'انتهى مزادك', 'انتهى المزاد رقم #' . $auction['id'] . ' بدون مزايدات', 'auction_end', $auction['id']);
                
                echo "⚠️ المزاد انتهى بدون مزايدات\n";
            }
            
            $conn->commit();
            $closed_count++;
            
        } catch (Exception $e) {
            $conn->rollBack();
            echo "❌ خطأ في معالجة المزاد #{$auction['id']}: " . $e->getMessage() . "\n";
        }
    }
    
    echo "\n========================================\n";
    echo "تم إغلاق {$closed_count} مزاد من أصل " . count($expired_auctions) . "\n";
    echo "انتهت العملية: " . date('Y-m-d H:i:s') . "\n";
    echo "========================================\n";
    
} catch (Exception $e) {
    echo "❌ خطأ عام: " . $e->getMessage() . "\n";
}
?>