<?php
// ai-chatbot.php - ضعه في مجلد includes/
function getChatbotWidget() {
    ?>
    <style>
        /* زر الشات العائم */
        .chat-float-button {
            position: fixed;
            bottom: 30px;
            left: 30px;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(99, 102, 241, 0.4);
            z-index: 9998;
            transition: all 0.3s;
            animation: pulse 2s infinite;
        }
        
        .chat-float-button:hover {
            transform: scale(1.1);
            box-shadow: 0 12px 32px rgba(99, 102, 241, 0.6);
        }
        
        .chat-float-button i {
            font-size: 1.8rem;
            color: white;
        }
        
        @keyframes pulse {
            0%, 100% {
                box-shadow: 0 8px 24px rgba(99, 102, 241, 0.4);
            }
            50% {
                box-shadow: 0 8px 24px rgba(99, 102, 241, 0.8), 0 0 0 10px rgba(99, 102, 241, 0.1);
            }
        }
        
        /* نافذة الشات */
        .chat-popup {
            position: fixed;
            bottom: 100px;
            left: 30px;
            width: 400px;
            height: 600px;
            background: #1e293b;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            z-index: 9999;
            display: none;
            flex-direction: column;
            overflow: hidden;
            animation: slideUp 0.3s ease-out;
        }
        
        .chat-popup.active {
            display: flex;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* هيدر الشات */
        .chat-header {
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .chat-header-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .chat-avatar {
            width: 45px;
            height: 45px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .chat-header-text h3 {
            color: white;
            font-size: 1.1rem;
            margin: 0;
            font-weight: 600;
        }
        
        .chat-header-text p {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.8rem;
            margin: 2px 0 0 0;
        }
        
        .chat-close {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s;
        }
        
        .chat-close:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(90deg);
        }
        
        /* محتوى الشات */
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #0f172a;
        }
        
        .chat-messages::-webkit-scrollbar {
            width: 6px;
        }
        
        .chat-messages::-webkit-scrollbar-track {
            background: rgba(148, 163, 184, 0.1);
        }
        
        .chat-messages::-webkit-scrollbar-thumb {
            background: rgba(99, 102, 241, 0.5);
            border-radius: 3px;
        }
        
        /* رسالة */
        .chat-message {
            margin-bottom: 16px;
            animation: fadeIn 0.3s;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .message-bot {
            display: flex;
            gap: 10px;
        }
        
        .message-user {
            display: flex;
            justify-content: flex-end;
        }
        
        .message-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1rem;
            flex-shrink: 0;
        }
        
        .message-content {
            background: #1e293b;
            padding: 12px 16px;
            border-radius: 12px;
            color: #f1f5f9;
            line-height: 1.6;
            max-width: 75%;
        }
        
        .message-user .message-content {
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        }
        
        .message-time {
            font-size: 0.7rem;
            color: #64748b;
            margin-top: 5px;
        }
        
        /* مؤشر الكتابة */
        .typing-indicator {
            display: none;
            gap: 10px;
            padding: 10px 0;
        }
        
        .typing-indicator.active {
            display: flex;
        }
        
        .typing-dots {
            display: flex;
            gap: 4px;
            padding: 12px 16px;
            background: #1e293b;
            border-radius: 12px;
        }
        
        .typing-dots span {
            width: 8px;
            height: 8px;
            background: #6366f1;
            border-radius: 50%;
            animation: bounce 1.4s infinite;
        }
        
        .typing-dots span:nth-child(2) {
            animation-delay: 0.2s;
        }
        
        .typing-dots span:nth-child(3) {
            animation-delay: 0.4s;
        }
        
        @keyframes bounce {
            0%, 60%, 100% {
                transform: translateY(0);
            }
            30% {
                transform: translateY(-10px);
            }
        }
        
        /* إدخال الرسالة */
        .chat-input-area {
            padding: 15px 20px;
            background: #1e293b;
            border-top: 1px solid rgba(148, 163, 184, 0.1);
        }
        
        .chat-input-wrapper {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .chat-input {
            flex: 1;
            background: #0f172a;
            border: 2px solid rgba(148, 163, 184, 0.2);
            border-radius: 12px;
            padding: 12px 16px;
            color: #f1f5f9;
            font-size: 0.95rem;
            font-family: 'Cairo', sans-serif;
            resize: none;
            max-height: 100px;
        }
        
        .chat-input:focus {
            outline: none;
            border-color: #6366f1;
        }
        
        .chat-input::placeholder {
            color: #64748b;
        }
        
        .chat-send-btn {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            border: none;
            border-radius: 12px;
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s;
        }
        
        .chat-send-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4);
        }
        
        .chat-send-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }
        
        /* Quick Actions */
        .quick-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            padding: 0 20px 15px;
        }
        
        .quick-action {
            background: rgba(99, 102, 241, 0.1);
            border: 1px solid rgba(99, 102, 241, 0.3);
            padding: 8px 14px;
            border-radius: 20px;
            color: #a5b4fc;
            font-size: 0.85rem;
            cursor: pointer;
            transition: 0.3s;
        }
        
        .quick-action:hover {
            background: rgba(99, 102, 241, 0.2);
            border-color: rgba(99, 102, 241, 0.5);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .chat-popup {
                left: 10px;
                right: 10px;
                bottom: 80px;
                width: auto;
                height: 500px;
            }
            
            .chat-float-button {
                left: 20px;
                bottom: 20px;
            }
        }
    </style>

    <!-- زر الشات العائم -->
    <div class="chat-float-button" id="chatFloatBtn">
        <i class="fas fa-comments"></i>
    </div>

    <!-- نافذة الشات -->
    <div class="chat-popup" id="chatPopup">
        <div class="chat-header">
            <div class="chat-header-info">
                <div class="chat-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="chat-header-text">
                    <h3>مساعد مزادات السيارات</h3>
                    <p>متصل الآن</p>
                </div>
            </div>
            <button class="chat-close" id="chatCloseBtn">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <div class="chat-messages" id="chatMessages">
            <div class="chat-message message-bot">
                <div class="message-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div>
                    <div class="message-content">
                        مرحباً! أنا مساعدك الذكي في مزادات السيارات 🚗<br>
                        كيف يمكنني مساعدتك اليوم؟
                    </div>
                    <div class="message-time" id="welcomeTime"></div>
                </div>
            </div>
        </div>

        <div class="quick-actions" id="quickActions">
            <div class="quick-action" data-action="أريد معرفة السيارات المتاحة">السيارات المتاحة</div>
            <div class="quick-action" data-action="ما هي أسعار السيارات؟">الأسعار</div>
            <div class="quick-action" data-action="كيف يمكنني المزايدة؟">كيفية المزايدة</div>
        </div>

        <div class="typing-indicator" id="typingIndicator">
            <div class="message-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="typing-dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <div class="chat-input-area">
            <div class="chat-input-wrapper">
                <textarea 
                    class="chat-input" 
                    id="chatInput" 
                    placeholder="اكتب رسالتك هنا..."
                    rows="1"
                ></textarea>
                <button class="chat-send-btn" id="chatSendBtn">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
    </div>

    <script>
        // تهيئة الشات
        const chatFloatBtn = document.getElementById('chatFloatBtn');
        const chatPopup = document.getElementById('chatPopup');
        const chatCloseBtn = document.getElementById('chatCloseBtn');
        const chatMessages = document.getElementById('chatMessages');
        const chatInput = document.getElementById('chatInput');
        const chatSendBtn = document.getElementById('chatSendBtn');
        const typingIndicator = document.getElementById('typingIndicator');
        const quickActions = document.querySelectorAll('.quick-action');

        // عرض الوقت في رسالة الترحيب
        document.getElementById('welcomeTime').textContent = new Date().toLocaleTimeString('ar-EG', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });

        // فتح/إغلاق الشات
        chatFloatBtn.addEventListener('click', () => {
            chatPopup.classList.toggle('active');
            if (chatPopup.classList.contains('active')) {
                chatInput.focus();
            }
        });

        chatCloseBtn.addEventListener('click', () => {
            chatPopup.classList.remove('active');
        });

        // إرسال رسالة
        function sendMessage(message) {
            if (!message.trim()) return;

            // إضافة رسالة المستخدم
            addMessage(message, 'user');
            chatInput.value = '';
            chatInput.style.height = 'auto';

            // إظهار مؤشر الكتابة
            typingIndicator.classList.add('active');
            chatMessages.scrollTop = chatMessages.scrollHeight;

            // إرسال للـ API
            fetch('get-chat-response.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: message })
            })
            .then(response => response.json())
            .then(data => {
                typingIndicator.classList.remove('active');
                
                if (data.success) {
                    addMessage(data.response, 'bot');
                } else {
                    addMessage('عذراً، حدث خطأ. يرجى المحاولة مرة أخرى.', 'bot');
                }
            })
            .catch(error => {
                typingIndicator.classList.remove('active');
                addMessage('عذراً، حدث خطأ في الاتصال.', 'bot');
                console.error('Error:', error);
            });
        }

        // إضافة رسالة للشات
        function addMessage(text, type) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `chat-message message-${type}`;
            
            const time = new Date().toLocaleTimeString('ar-EG', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });

            if (type === 'bot') {
                messageDiv.innerHTML = `
                    <div class="message-avatar">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div>
                        <div class="message-content">${text}</div>
                        <div class="message-time">${time}</div>
                    </div>
                `;
            } else {
                messageDiv.innerHTML = `
                    <div>
                        <div class="message-content">${text}</div>
                        <div class="message-time">${time}</div>
                    </div>
                `;
            }

            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        // زر الإرسال
        chatSendBtn.addEventListener('click', () => {
            sendMessage(chatInput.value);
        });

        // Enter للإرسال
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage(chatInput.value);
            }
        });

        // Auto-resize textarea
        chatInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        });

        // Quick Actions
        quickActions.forEach(action => {
            action.addEventListener('click', () => {
                sendMessage(action.dataset.action);
            });
        });
    </script>
    <?php
}
?>